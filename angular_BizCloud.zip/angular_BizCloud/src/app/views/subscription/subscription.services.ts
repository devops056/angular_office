import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class SubscriptionService {

    constructor(private http: HttpClient) { }

    getAllAdList(data) {
        return this.http.post(environment.APIURL + "api/getAllAdvertisementPlanListing", data);
    }

    getAllUserList(data) {
        return this.http.post(environment.APIURL + "api/getAllUserPlanListing", data);
    }
}
