import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PackageComponent } from './package/package.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';
import { SubscriptionRoutingModule } from './subscription-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { SubscriptionService } from './subscription.services';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    declarations: [PackageComponent, AdvertisementComponent],
    imports: [
        CommonModule,
        SubscriptionRoutingModule,
        DataTablesModule,
        BsDatepickerModule.forRoot(),
        ReactiveFormsModule,
        FormsModule
    ],
    providers: [SubscriptionService]
})
export class SubscriptionModule { }
