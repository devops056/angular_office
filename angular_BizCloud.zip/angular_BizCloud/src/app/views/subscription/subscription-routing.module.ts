import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PackageComponent } from './package/package.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';
import { AdminAuth } from '../../helpers/adminAuth';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Subscription'
        },
        children: [
            {
                path: '',
                redirectTo: 'package'
            },
            {
                path: 'package',
                component: PackageComponent,
                data: {
                    title: 'User Plan'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'advertisement',
                component: AdvertisementComponent,
                data: {
                    title: 'Advertisement'
                },
                canActivate: [AdminAuth]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SubscriptionRoutingModule { }
