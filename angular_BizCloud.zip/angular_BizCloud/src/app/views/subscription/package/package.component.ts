import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { SubscriptionService } from '../subscription.services';

@Component({
    selector: 'app-package',
    templateUrl: './package.component.html'
})
export class PackageComponent implements OnInit {

    colorTheme = "theme-blue"
    bsConfig: Partial<BsDatepickerConfig>;

    dtOptions: DataTables.Settings = {};
    ads: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    filterForm: FormGroup;

    isNoDataVisible = true;

    totalRevenue = 0;

    constructor(
        public pageTitle: Title,
        private toasterService: ToastrService,
        private subscriptionFactory: SubscriptionService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Package");
        this.bsConfig = Object.assign({}, { containerClass: this.colorTheme });
        this.getAllUserPlanListing()
        this.createForm()
    }

    createForm() {
        this.filterForm = new FormGroup({
            'from_date': new FormControl(''),
            'to_date': new FormControl('')
        });
    }

    getAllUserPlanListing() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            // stateSave: true,
            "order": [0, "desc"],
            ajax: (dataTablesParameters: any, callback) => {

                if (this.filterForm.value.from_date) {
                    let fromDateObj = new Date(this.filterForm.value.from_date)
                    let fromDate = fromDateObj.getFullYear() + '-' + (fromDateObj.getMonth() + 1) + '-' + fromDateObj.getDate()
                    dataTablesParameters.from_date = fromDate + ' 00:00:00.000 +00:00'
                }

                if (this.filterForm.value.to_date) {
                    let toDateObj = new Date(this.filterForm.value.to_date)
                    let toDate = toDateObj.getFullYear() + '-' + (toDateObj.getMonth() + 1) + '-' + toDateObj.getDate()
                    dataTablesParameters.to_date = toDate + ' 23:59:59.000 +00:00'
                }

                this.subscriptionFactory
                    .getAllUserList(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.ads = resData.data;

                            this.totalRevenue = resData.totalAmount

                            this.isNoDataVisible = true;

                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toasterService.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "createdAt", searchable: false },
                { data: "", name: "userTransactionDetails.email" },
                { data: "totalMonth", searchable: false },
                { data: "", name: "userTransactionDetails.planExpiryDate", searchable: false },
                { data: "txnId" },
                { data: "paymentStatus" },
                { data: "amount", searchable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

    filterFormSubmit() {

        // if (this.filterForm.value.from_date != '' || this.filterForm.value.to_date != '') {
            if (this.filterForm.value.from_date && this.filterForm.value.to_date) {
                if (new Date(this.filterForm.value.from_date).getTime() > new Date(this.filterForm.value.to_date).getTime()) {
                    this.toasterService.error("To date has to be bigger than from date.", "Error")
                    return;
                } else {
                    this.isNoDataVisible = false;
                    this.rerender()
                }
            } else {
                this.toasterService.error("Please select from and to date.", "Error")
            }
        // }
    }

    onReset() {
        this.isNoDataVisible = false;

        this.filterForm.patchValue({
            'from_date': '',
            'to_date': ''
        })
        this.rerender()
    }

}
