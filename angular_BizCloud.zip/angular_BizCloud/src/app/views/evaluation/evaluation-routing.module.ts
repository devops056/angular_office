import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuth } from '../../helpers/adminAuth';
import { EvaluationComponent } from './evaluation/evaluation.component';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Evaluation'
        },
        children: [
            {
                path: '',
                redirectTo: 'evaluation'
            },
            {
                path: '',
                component: EvaluationComponent,
                data: {
                    title: ''
                },
                canActivate: [AdminAuth]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EvaluationRoutingModule { }
