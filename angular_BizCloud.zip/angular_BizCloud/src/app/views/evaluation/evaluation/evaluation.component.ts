import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { param } from 'jquery';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import Swal from 'sweetalert2';
import { environment } from '../../../../environments/environment';
import { EvaluationService } from '../evaluation.services';
import { ViewEvaluationDetailsComponent } from './view-evaluation-details/view-evaluation-details.component';

@Component({
    selector: 'app-evaluation',
    templateUrl: './evaluation.component.html'
})
export class EvaluationComponent implements OnInit {

    colorTheme = "theme-blue"

    bsConfig: Partial<BsDatepickerConfig>;

    modalRef: BsModalRef;

    dtOptions: DataTables.Settings = {};
    postList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    filterForm: FormGroup;

    baseURLPath = environment.GETIMGFOLDER + "profile/";

    currentType;
    currentId;

    constructor(
        public pageTitle: Title,
        private toasterService: ToastrService,
        private modalService: BsModalService,
        private route: ActivatedRoute,
        private evaluationFactory: EvaluationService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud -  Evaluation");
        this.bsConfig = Object.assign({}, { containerClass: this.colorTheme });
        this.createForm()
    }

    createForm() {
        this.filterForm = new FormGroup({
            'type': new FormControl(''),
            'from_date': new FormControl(''),
            'to_date': new FormControl('')
        });

        // default type
        this.route.params.subscribe(params => {
            this.currentType = params.type
            this.currentId = params.id

            //patch
            this.filterForm.patchValue({
                type: this.currentType
            })
        })

        this.fetchListingBasedOnCondition()
    }

    detailsModal(id, type) {
        if (type == 'post') {
            const initialState = { postId: id, type: "Post" };
            this.modalRef = this.modalService.show(ViewEvaluationDetailsComponent, {
                class: 'modal-dialog-centered modal-lg',
                initialState
            });
        } else if (type == 'moment') {
            const initialState = { postId: id, type: "Moment" };
            this.modalRef = this.modalService.show(ViewEvaluationDetailsComponent, {
                class: 'modal-dialog-centered modal-lg',
                initialState
            });
        } else if (type == 'article') {
            const initialState = { postId: id, type: "Article" };
            this.modalRef = this.modalService.show(ViewEvaluationDetailsComponent, {
                class: 'modal-dialog-centered modal-lg',
                initialState
            });
        }
    }

    fetchListingBasedOnCondition() {
        // console.log(this.currentType, this.currentId)

        // if (this.currentType.toLowerCase() == 'post' && this.currentId == 0) {
        // fetch all reported posts
        this.postListDataTableDetails(this.currentId)

        // } else if (this.currentType.toLowerCase() == 'post' && this.currentId != 0) {
        //     // fetch all reported posts with given post id
        //     this.postListDataTableDetails(this.currentId)

        // } else if (this.currentType.toLowerCase() == 'moment' && this.currentId == 0) {
        //     // fetch all reported moments
        //     this.postListDataTableDetails(this.currentId)
        //     // this.momentListDataTableDetails(this.currentId)

        // } else if (this.currentType.toLowerCase() == 'moment' && this.currentId != 0) {
        //     // fetch all reported moments with given moment id
        //     this.postListDataTableDetails(this.currentId)
        //     // this.momentListDataTableDetails(this.currentId)
        // }

    }

    // first time call
    // include conditions based on type
    postListDataTableDetails(currentId) {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            // stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {

                if (this.currentId != 0) {
                    dataTablesParameters.postId = currentId
                }

                if (this.filterForm.value.type) {
                    dataTablesParameters.type = this.filterForm.value.type
                }

                if (this.filterForm.value.from_date) {
                    let fromDateObj = new Date(this.filterForm.value.from_date)
                    let fromDate = fromDateObj.getFullYear() + '-' + (fromDateObj.getMonth() + 1) + '-' + fromDateObj.getDate()
                    dataTablesParameters.from_date = fromDate + ' 00:00:00.000 +00:00'
                }

                if (this.filterForm.value.to_date) {
                    let toDateObj = new Date(this.filterForm.value.to_date)
                    let toDate = toDateObj.getFullYear() + '-' + (toDateObj.getMonth() + 1) + '-' + toDateObj.getDate()
                    dataTablesParameters.to_date = toDate + ' 23:59:59.000 +00:00'
                }

                this.evaluationFactory
                    .getAllReportedPostListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.postList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toasterService.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "createdAt", searchable: false },
                { data: "issue" },
                { data: "", name: "userDetails.firstName" },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    // momentListDataTableDetails(currentId) {
    //     this.dtOptions = {
    //         pagingType: "full_numbers",
    //         pageLength: 10,
    //         serverSide: true,
    //         processing: true,
    //         stateSave: true,
    //         ajax: (dataTablesParameters: any, callback) => {

    //             if (this.currentId != 0) {
    //                 dataTablesParameters.momentId = currentId
    //             }

    //             this.evaluationFactory
    //                 .getAllReportedMomentListing(dataTablesParameters)
    //                 .subscribe(
    //                     respones => {
    //                         let resData = JSON.parse(JSON.stringify(respones));
    //                         this.postList = resData.data;
    //                         callback({
    //                             recordsTotal: resData.recordsTotal,
    //                             recordsFiltered: resData.recordsFiltered,
    //                             data: []
    //                         });
    //                     },
    //                     error => {
    //                         this.toasterService.error(
    //                             "Oops! something went wrong !.",
    //                             "Error"
    //                         );
    //                     }
    //                 );
    //         },
    //         scrollCollapse: true,
    //         columns: [
    //             { data: "createdAt", searchable: false },
    //             { data: "issue" },
    //             { data: "", name: "userDetails.firstName" },
    //             { data: "", searchable: false, orderable: false }
    //         ]
    //     };
    // }

    filterFormSubmit() {

        console.log(this.filterForm.value)

        if (this.filterForm.value.from_date != '' || this.filterForm.value.to_date != '') {
            if (this.filterForm.value.from_date && this.filterForm.value.to_date) {
                if (new Date(this.filterForm.value.from_date).getTime() > new Date(this.filterForm.value.to_date).getTime()) {
                    this.toasterService.error("To date has to be bigger than from date.", "Error")
                    return;
                } else {
                    this.rerender()
                }
            } else {
                this.toasterService.error("Please select from and to date.", "Error")
            }
        } else {
            this.rerender()
        }

        // if (this.filterForm.value.from_date && this.filterForm.value.to_date) {

        //     // compare date
        //     if (new Date(this.filterForm.value.from_date).getTime() > new Date(this.filterForm.value.to_date).getTime()) {
        //         this.toasterService.error("To date has to be bigger then from date.", "Error")
        //         return;
        //     } else {
        //         this.currentType = this.filterForm.value.type
        //         this.rerender()
        //     }

        // } else {
        //     this.toasterService.error("Please select all filters.", "Error");
        // }

    }

    onReset() {
        this.filterForm.patchValue({
            'type': 'all',
            'from_date': '',
            'to_date': ''
        })
        this.currentId = 0
        this.rerender()
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }


    changeStatus(id, status, currentType) {
        // if (currentType.toLowerCase() == 'post') {
        this.changePostStatus(id, status, 'post')
        // } else if (currentType.toLowerCase() == 'moment') {
        //     this.changePostStatus(id, status, 'moment')
        // }
    }

    resolveEvaluation(id, postId, currentType) {
        // if (currentType.toLowerCase() == 'post') {
        this.resolvePost(id, postId)
        // } else if (currentType.toLowerCase() == 'moment') {
        //     this.resolveMoment(id, postId)
        // }
    }


    changePostStatus(postId, type, postType) {
        let text;
        let confirmButtonColor = "#008000";
        let confirmButtonText;
        let succMsg;

        if (postType == 'post') {
            text = "You want to activate this post?";
            confirmButtonText = "Yes, Active it!";
            let succTitle = "Activated";
            succMsg = "Post has been activated.";
            if (type === 'inactive') {
                text = "You want to deactivate this post?";
                confirmButtonText = "Yes, Deactive it!";
                succTitle = "Deactivated";
                succMsg = "Post has been deactivated.";
            }
        } else if (postType == 'moment') {
            text = "You want to activate this moment?";
            confirmButtonText = "Yes, Active it!";
            let succTitle = "Activated";
            succMsg = "Moment has been activated.";
            if (type === 'inactive') {
                text = "You want to deactivate this moment?";
                confirmButtonText = "Yes, Deactive it!";
                succTitle = "Deactivated";
                succMsg = "Moment has been deactivated.";
            }
        }

        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.evaluationFactory.activeInActivePost({ "postId": postId, "status": type }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toasterService.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }



    resolvePost(id, postId) {
        let text = "You want to resolve?";
        let confirmButtonText = "Yes, Resolve it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Resolved";
        let succMsg = "Resolved successfully.";

        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.evaluationFactory.resolveReportedPost({ "id": id, "postId": postId }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toasterService.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }


    // resolveMoment(id, momentId) {
    //     let text = "You want to resolve?";
    //     let confirmButtonText = "Yes, Resolve it!";
    //     let confirmButtonColor = "#008000";
    //     let succTitle = "Resolved";
    //     let succMsg = "Resolved successfully.";

    //     Swal.fire({
    //         title: 'Are you sure?',
    //         text: text,
    //         icon: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: confirmButtonColor,
    //         cancelButtonColor: '#d33',
    //         confirmButtonText: confirmButtonText
    //     }).then((result) => {
    //         if (result.isConfirmed) {
    //             this.evaluationFactory.resolveReportedMoment({ "id": id, "momentId": momentId }).subscribe(
    //                 response => {
    //                     Swal.fire(succMsg, '', 'success')
    //                     this.rerender();
    //                 },
    //                 error => {
    //                     this.toasterService.error("Oops! something went wrong!.", "Error");
    //                 }
    //             );
    //         }
    //     })
    // }




}
