import { Component, Input, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { environment } from '../../../../../environments/environment';
import { EvaluationService } from '../../evaluation.services';


@Component({
  selector: 'app-view-evaluation-details',
  templateUrl: './view-evaluation-details.component.html',
  styleUrls: ['./view-evaluation-details.component.scss']
})
export class ViewEvaluationDetailsComponent implements OnInit {

  @Input() postId;

  baseURLPathProfile = environment.GETIMGFOLDER + "profile/"
  baseURLPathImg = environment.GETIMGFOLDER + "post/image/"
  baseURLPathVideo = environment.GETIMGFOLDER + "post/video/"

  postDetails;

  slides = [];

  slideConfig = { "slidesToShow": 1, "slidesToScroll": 1 };

  type;

  constructor(
    private modalService: BsModalService,
    public modalRef: BsModalRef,
    private momentFactory: EvaluationService
  ) { }

  ngOnInit(): void {
    this.momentFactory.getPostDetails(this.postId).subscribe(res => {
      let getPostDetails = JSON.parse(JSON.stringify(res))

      if (getPostDetails.status == 200) {
        this.postDetails = getPostDetails.data;

        if (this.postDetails.PostMedias.length > 0) {
          if (this.postDetails.PostMedias[0].mediaType == 'image') {
            for (let postImg of this.postDetails.PostMedias) {
              this.slides.push({ "img": this.baseURLPathImg + postImg.mediaFile })
            }
          } else {

          }
        }

      } else {
        this.postDetails = [];
      }

    })
  }

  onClose() {
    this.modalRef.hide()
  }

  userImgErr(event) {
    event.target.src = environment.PLACEHOLDERIMG
  }

}
