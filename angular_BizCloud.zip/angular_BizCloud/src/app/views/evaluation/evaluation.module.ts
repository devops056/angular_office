import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EvaluationRoutingModule } from './evaluation-routing.module';
import { EvaluationComponent } from './evaluation/evaluation.component';
import { DataTablesModule } from 'angular-datatables';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ReactiveFormsModule } from '@angular/forms';
import { EvaluationService } from './evaluation.services';
import { ViewEvaluationDetailsComponent } from './evaluation/view-evaluation-details/view-evaluation-details.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { SharedModule } from '../shared/shared.module';
// import { DateAgoPipe } from '../../pipes/date-ago.pipe';


@NgModule({
    declarations: [EvaluationComponent, ViewEvaluationDetailsComponent],
    imports: [
        CommonModule,
        EvaluationRoutingModule,
        DataTablesModule,
        ModalModule.forRoot(),
        BsDatepickerModule.forRoot(),
        ReactiveFormsModule,
        SlickCarouselModule,
        SharedModule
    ],
    providers: [EvaluationService],
    entryComponents: [ViewEvaluationDetailsComponent]
})
export class EvaluationModule { }
