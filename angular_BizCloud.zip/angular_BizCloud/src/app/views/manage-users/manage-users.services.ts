import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable()
export class UsermanagementService {

    constructor(private http: HttpClient) {
    }

    getAllUserListing(data) {
        return this.http.post(environment.APIURL + 'api/getAllUserListing', data);
    }

    activeInActiveUsers(data) {
        return this.http.post(environment.APIURL + 'api/activeInActiveUsers', data);
    }

    getUserDetails(userId) {
        return this.http.get(environment.APIURL + 'api/getUserDetails?userId=' + userId);
    }

    getUserBusinessGoal(userId) {
        return this.http.get(environment.APIURL + 'api/getUserBusinessGoal?userId=' + userId);
    }

    getUserExpertise(userId) {
        return this.http.get(environment.APIURL + 'api/getUserExpertise?userId=' + userId);
    }

    getUserPrefrences(userId) {
        return this.http.get(environment.APIURL + 'api/getUserPrefrences?userId=' + userId);
    }

    getUserIndustry(userId) {
        return this.http.get(environment.APIURL + 'api/getUserIndutries?userId=' + userId);
    }

    getUserGroup(userId) {
        return this.http.get(environment.APIURL + 'api/getUserGroups?userId=' + userId);
    }

}
