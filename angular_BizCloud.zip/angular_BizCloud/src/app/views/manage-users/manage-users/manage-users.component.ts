import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { UsermanagementService } from '../manage-users.services';
import swal from 'sweetalert2'
import { environment } from '../../../../environments/environment';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
    selector: 'app-manage-users',
    templateUrl: './manage-users.component.html'
})
export class ManageUsersComponent implements OnInit, AfterViewInit, OnDestroy {

    colorTheme = "theme-blue"
    bsConfig: Partial<BsDatepickerConfig>;

    dtOptions: DataTables.Settings = {};
    users: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    filterForm: FormGroup;

    baseURLPath = environment.GETIMGFOLDER + "profile/"

    isNoDataVisible = true;

    constructor(
        public pageTitle: Title,
        private toasterService: ToastrService,
        private userFactory: UsermanagementService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Manage Users");
        this.bsConfig = Object.assign({}, { containerClass: this.colorTheme });
        this.createForm();
        this.getallUsers();
    }

    createForm() {
        this.filterForm = new FormGroup({
            'member_type': new FormControl(''),
            'from_date': new FormControl(''),
            'to_date': new FormControl('')
        });
    }

    getallUsers() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            // stateSave: true,
            // 'columnDefs': [ {
            //     'targets': [0], // column index (start from 0)
            //     'orderable': false, // set orderable false for selected columns
            //  }],
            "order": [1, "asc"],
            ajax: (dataTablesParameters: any, callback) => {

                if (this.filterForm.value.member_type) {
                    dataTablesParameters.member_type = this.filterForm.value.member_type
                }

                if (this.filterForm.value.from_date) {
                    let fromDateObj = new Date(this.filterForm.value.from_date)
                    let fromDate = fromDateObj.getFullYear() + '-' + (fromDateObj.getMonth() + 1) + '-' + fromDateObj.getDate()
                    dataTablesParameters.from_date = fromDate + ' 00:00:00.000 +00:00'
                }

                if (this.filterForm.value.to_date) {
                    let toDateObj = new Date(this.filterForm.value.to_date)
                    let toDate = toDateObj.getFullYear() + '-' + (toDateObj.getMonth() + 1) + '-' + toDateObj.getDate()
                    dataTablesParameters.to_date = toDate + ' 23:59:59.000 +00:00'
                }

                this.userFactory
                    .getAllUserListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.users = resData.data;

                            // this.isNoDataVisible = false;
                            this.isNoDataVisible = true;

                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toasterService.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "profilePicture", searchable: false, orderable: false },
                { data: "email" },
                { data: "firstName" },
                { data: "lastName" },
                { data: "phoneNumber" },
                { data: "userType" },
                { data: "createdAt", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    userImgErr(event) {
        event.target.src = environment.PLACEHOLDERIMG
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    changedUserStatus(userId, type) {
        let text = "You want to activate this user?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "User has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this user?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "User has been deactivated.";
        }
        swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.userFactory.activeInActiveUsers({ "userId": userId, "status": type }).subscribe(
                    response => {
                        swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toasterService.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }


    filterFormSubmit() {
        // console.log(this.filterForm.value)
        // this.filterForm.value.member_type &&

        if (this.filterForm.value.from_date != '' || this.filterForm.value.to_date != '') {
            if (this.filterForm.value.from_date && this.filterForm.value.to_date) {
                if (new Date(this.filterForm.value.from_date).getTime() > new Date(this.filterForm.value.to_date).getTime()) {
                    this.toasterService.error("To date has to be bigger than from date.", "Error")
                    return;
                } else {
                    this.isNoDataVisible = false;
                    this.rerender()
                }
            } else {
                this.toasterService.error("Please select from and to date.", "Error")
            }
        } else {
            this.isNoDataVisible = false;
            this.rerender()
        }
        // else {
        //     if (new Date(this.filterForm.value.from_date).getTime() > new Date(this.filterForm.value.to_date).getTime()) {
        //         this.toasterService.error("To date has to be bigger than from date.", "Error")
        //         return;
        //     } else {
        //         this.rerender()
        //     }
        // }



        // if (this.filterForm.value.member_type) {

        //     if (this.filterForm.value.from_date && this.filterForm.value.to_date) {
        //         // compare date
        //         if (new Date(this.filterForm.value.from_date).getTime() >  new Date(this.filterForm.value.to_date).getTime()) {
        //             this.toasterService.error("To date has to be bigger than from date.", "Error")
        //             return;
        //         } else {
        //             this.rerender()
        //         }
        //     } else {
        //         this.rerender()
        //     }


        // } else {
        //     this.rerender()
        // }

    }

    onReset() {
        this.isNoDataVisible = false;

        this.filterForm.patchValue({
            'member_type': '',
            'from_date': '',
            'to_date': ''
        })
        this.rerender()
    }
}
