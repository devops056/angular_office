import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { DetailsComponent } from './details/details.component';
import { AdminAuth } from '../../helpers/adminAuth';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Manage Users'
        },
        children: [
            {
                path: '',
                redirectTo: 'manage-users'
            },
            {
                path: '',
                component: ManageUsersComponent,
                data: {
                    title: ''
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'details/:userId',
                component: DetailsComponent,
                data: {
                    title: 'User Details'
                },
                canActivate: [AdminAuth]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ManageUsersRoutingModule { }
