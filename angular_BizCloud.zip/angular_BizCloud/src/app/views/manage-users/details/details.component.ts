import { Component, OnInit, TemplateRef } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { UsermanagementService } from '../manage-users.services';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../../environments/environment';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


@Component({
    selector: 'app-details',
    templateUrl: './details.component.html'
})
export class DetailsComponent implements OnInit {

    userId: string = "";
    userDetails: any = {};
    pairedData: Array<any> = [];
    selfMatchData: Array<any> = [];
    modalRef: BsModalRef;

    userExpertise: Array<any> = [];
    userPreference: Array<any> = [];

    industryData: Array<any> = [];
    userGroupData: Array<any> = [];
    

    baseURLPath = environment.GETIMGFOLDER + "profile/"

    constructor(
        public pageTitle: Title,
        private location: Location,
        public route: ActivatedRoute,
        public userFactory: UsermanagementService,
        public toasterService: ToastrService,
        private modalService: BsModalService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Users Detsils");
        this.route.params.subscribe(params => {
            this.userId = params.userId;
        });
        this.getUserDetails();
    }

    userImgErr(event) {
        event.target.src = environment.PLACEHOLDERIMG
    }

    getUserDetails() {
        this.userFactory.getUserDetails(this.userId).subscribe(
            response => {
                let getuserDetails = JSON.parse(JSON.stringify(response));
                if (getuserDetails.status == 200) {
                    this.userDetails = getuserDetails.data;
                } else {
                    this.userDetails = {};
                }
            },
            error => {
                this.toasterService.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    goBack() {
        this.location.back();
    }

    openBusinessGoalModal(businessGoal: TemplateRef<any>) {
        this.modalRef = this.modalService.show(businessGoal, Object.assign({}, { class: 'modal-lg' }));
        this.userFactory.getUserBusinessGoal(this.userId).subscribe(
            response => {
                let usersBusinessGoals = JSON.parse(JSON.stringify(response));
                if (usersBusinessGoals.status == 200) {
                    this.pairedData = usersBusinessGoals.data.pairedGoals;
                    this.selfMatchData = usersBusinessGoals.data.selfMatchGoals
                } else {
                    this.pairedData = [];
                    this.selfMatchData = [];
                }
            },
            error => {
                this.toasterService.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    openIndustriesModal(industries: TemplateRef<any>){
        this.modalRef = this.modalService.show(industries, Object.assign({}, { class: 'modal-lg' }));
        this.userFactory.getUserIndustry(this.userId).subscribe(
            response => {
                let industryData = JSON.parse(JSON.stringify(response));
                if (industryData.status == 200) {
                    this.industryData = industryData.data.userIndustries;
                } else {
                    this.industryData = [];
                }
            },
            error => {
                this.toasterService.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    openPreferenceModal(preferences: TemplateRef<any>){
        this.modalRef = this.modalService.show(preferences, Object.assign({}, { class: 'modal-lg' }));
        this.userFactory.getUserPrefrences(this.userId).subscribe(
            response => {
                let userPrefrences = JSON.parse(JSON.stringify(response));
                if (userPrefrences.status == 200) {
                    this.userPreference = userPrefrences.data.userPrefrences;
                } else {
                    this.userPreference = [];
                }
            },
            error => {
                this.toasterService.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    openExpertiseModal(expertise: TemplateRef<any>){
        this.modalRef = this.modalService.show(expertise, Object.assign({}, { class: 'modal-lg' }));
        this.userFactory.getUserExpertise(this.userId).subscribe(
            response => {
                let userExpertise = JSON.parse(JSON.stringify(response));
                if (userExpertise.status == 200) {
                    this.userExpertise = userExpertise.data.userExpertise;
                } else {
                    this.userExpertise = [];
                }
            },
            error => {
                this.toasterService.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    openUserGroupModal(userGroup: TemplateRef<any>){
        this.modalRef = this.modalService.show(userGroup, Object.assign({}, { class: 'modal-lg' }));
        this.userFactory.getUserGroup(this.userId).subscribe(
            response => {
                let groupData = JSON.parse(JSON.stringify(response));
                if (groupData.status == 200) {
                    this.userGroupData = groupData.data.userGroups;
                } else {
                    this.userGroupData = [];
                }
            },
            error => {
                this.toasterService.error("Oops! Something went wrong!", "Error")
            }
        );
    }

}
