import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManageUsersComponent } from './manage-users/manage-users.component';
import { DetailsComponent } from './details/details.component';
import { ManageUsersRoutingModule } from './manage-users-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { UsermanagementService } from './manage-users.services';
import { ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TabsModule } from 'ngx-bootstrap/tabs';

@NgModule({
    declarations: [ManageUsersComponent, DetailsComponent],
    imports: [
        CommonModule,
        ManageUsersRoutingModule,
        DataTablesModule,
        BsDatepickerModule.forRoot(),
        ReactiveFormsModule,
        ModalModule.forRoot(),
        TabsModule.forRoot()
    ],
    providers: [UsermanagementService]
})
export class ManageUsersModule { }
