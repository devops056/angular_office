import { Component, OnInit, TemplateRef } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GenerateCodeService } from '../generate-code.services';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CustomValidators } from '../../../helpers/custom-validators';


@Component({
    selector: 'app-add',
    templateUrl: './add.component.html'
})
export class AddComponent implements OnInit {

    isCodeGenerated = false;
    generatedCode = null;
    clicked = false;

    modalRef: BsModalRef;

    sendEmailForm : FormGroup;
    sendSMSForm: FormGroup;

    submitted: boolean = false;
    submitted1: boolean = false;

    constructor(
        public pageTitle: Title,
        private location: Location,
        public router: Router,
        private toastr: ToastrService,
        private generateCodeFactory: GenerateCodeService,
        private modalService: BsModalService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Add VIP Code");
    }

    generatePromoCode() {
        this.generateCodeFactory.addNewVIPCode().subscribe(res => {
            let parsedRes = JSON.parse(JSON.stringify(res));
            if (parsedRes.status == 200) {
                this.toastr.success(parsedRes.message, 'Success');
                this.generatedCode = parsedRes.data.promoCode
                this.isCodeGenerated = true;
            } else {
                this.toastr.error(parsedRes.message, 'Error');
            }
        })
    }

    goBack() {
        this.location.back();
    }

    openSendMailModal(sendemail: TemplateRef<any>) {
        this.createSendEmailForm()

        this.modalRef = this.modalService.show(sendemail, Object.assign({}, { class: 'modal-lg' }));
        
    }

    createSendEmailForm() {
        this.sendEmailForm = new FormGroup({
            'sendEmail': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator, Validators.email]),
            'type': new FormControl('email'),
            'promoCode': new FormControl(this.generatedCode)
        });
    }

    sendEmailSubmit() {
        this.submitted = true
        
        if (this.sendEmailForm.valid) {
            this.generateCodeFactory.sendVIPCode(this.sendEmailForm.value).subscribe(res => {
                let resData = JSON.parse(JSON.stringify(res));
                if (resData.status == 200) {
                    this.toastr.success(resData.message, 'Success');
                    this.modalRef.hide()
                    // this.router.navigate(["/generate-code"]);
                } else {
                    this.toastr.error(resData.message, 'Error');
                }
            }, error => {
                this.toastr.error('Oops! something went wrong', 'Error');
            })
        }

    }

    openSendSMSModal(sendSMS: TemplateRef<any>) {
        this.createSendSMSForm()

        this.modalRef = this.modalService.show(sendSMS, Object.assign({}, { class: 'modal-lg' }));
    }

    createSendSMSForm() {
        this.sendSMSForm = new FormGroup({
            'sendSMS': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'type': new FormControl('sms'),
            'promoCode': new FormControl(this.generatedCode)
        });
    }

    sendSMSSubmit() {
        this.submitted1 = true
        
        if (this.sendSMSForm.valid) {
            this.generateCodeFactory.sendVIPCode(this.sendSMSForm.value).subscribe(res => {
                let resData = JSON.parse(JSON.stringify(res));
                if (resData.status == 200) {
                    this.toastr.success(resData.message, 'Success');
                    this.modalRef.hide()
                    // this.router.navigate(["/generate-code"]);
                } else {
                    this.toastr.error(resData.message, 'Error');
                }
            }, error => {
                this.toastr.error('Oops! something went wrong', 'Error');
            })
        }
    }

}
