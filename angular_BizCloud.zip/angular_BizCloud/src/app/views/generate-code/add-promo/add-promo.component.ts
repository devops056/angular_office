import { Component, OnInit, TemplateRef } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GenerateCodeService } from '../generate-code.services';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { CustomValidators } from '../../../helpers/custom-validators';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-add-promo',
  templateUrl: './add-promo.component.html',
  styleUrls: ['./add-promo.component.scss']
})
export class AddPromoComponent implements OnInit {

  isCodeGenerated = false;
  generatedCode = null;
  clicked = false;

  modalRef: BsModalRef;

  sendEmailForm: FormGroup;
  sendSMSForm: FormGroup;

  submitted: boolean = false;
  submitted1: boolean = false;

  formSubmitted: boolean = true;

  colorTheme = "theme-blue"
  bsConfig: Partial<BsDatepickerConfig>;

  codeForm: FormGroup;
  today = new Date(Date.now() + ( 3600 * 1000 * 24));

  constructor(
    public pageTitle: Title,
    private location: Location,
    public router: Router,
    private toastr: ToastrService,
    private generateCodeFactory: GenerateCodeService,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.pageTitle.setTitle("BizCloud - Add Promo Code");
    this.bsConfig = Object.assign({}, { containerClass: this.colorTheme });
    
    this.createForm()
  }

  createForm() {
    this.codeForm = new FormGroup({
      'expiryDate': new FormControl('', [Validators.required])
    });
  }

  generatePromoCode() {
    this.formSubmitted = true;

    if (this.codeForm.valid) {
      this.generateCodeFactory.addNewPromoCode({ 'expiryDate': this.codeForm.value.expiryDate }).subscribe(res => {
        this.clicked = true

        let parsedRes = JSON.parse(JSON.stringify(res));
        if (parsedRes.status == 200) {
          this.toastr.success(parsedRes.message, 'Success');
          this.generatedCode = parsedRes.data.promoCode
          this.isCodeGenerated = true;
        } else {
          this.toastr.error(parsedRes.message, 'Error');
        }

      })

    } else {
      this.toastr.error("Expiry date is required.", 'Error');
    }
    // (click)="generatePromoCode(); clicked = true;"


  }

  goBack() {
    this.location.back();
  }

  openSendMailModal(sendemail: TemplateRef<any>) {
    this.createSendEmailForm()

    this.modalRef = this.modalService.show(sendemail, Object.assign({}, { class: 'modal-lg' }));

  }

  createSendEmailForm() {
    this.sendEmailForm = new FormGroup({
      'sendEmail': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator, Validators.email]),
      'type': new FormControl('email'),
      'promoCode': new FormControl(this.generatedCode)
    });
  }

  sendEmailSubmit() {
    this.submitted = true

    if (this.sendEmailForm.valid) {
      this.generateCodeFactory.sendPromoCode(this.sendEmailForm.value).subscribe(res => {
        let resData = JSON.parse(JSON.stringify(res));
        if (resData.status == 200) {
          this.toastr.success(resData.message, 'Success');
          this.modalRef.hide()
          // this.router.navigate(["/generate-code"]);
        } else {
          this.toastr.error(resData.message, 'Error');
        }
      }, error => {
        this.toastr.error('Oops! something went wrong', 'Error');
      })
    }

  }

  openSendSMSModal(sendSMS: TemplateRef<any>) {
    this.createSendSMSForm()

    this.modalRef = this.modalService.show(sendSMS, Object.assign({}, { class: 'modal-lg' }));
  }

  createSendSMSForm() {
    this.sendSMSForm = new FormGroup({
      'sendSMS': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
      'type': new FormControl('sms'),
      'promoCode': new FormControl(this.generatedCode)
    });
  }

  sendSMSSubmit() {
    this.submitted1 = true

    if (this.sendSMSForm.valid) {
      this.generateCodeFactory.sendPromoCode(this.sendSMSForm.value).subscribe(res => {
        let resData = JSON.parse(JSON.stringify(res));
        if (resData.status == 200) {
          this.toastr.success(resData.message, 'Success');
          this.modalRef.hide()
          // this.router.navigate(["/generate-code"]);
        } else {
          this.toastr.error(resData.message, 'Error');
        }
      }, error => {
        this.toastr.error('Oops! something went wrong', 'Error');
      })
    }
  }

}
