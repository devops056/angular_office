import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { CustomValidators } from '../../../helpers/custom-validators';
import { GenerateCodeService } from '../generate-code.services';

@Component({
    selector: 'app-generate-code',
    templateUrl: './generate-code.component.html'
})
export class GenerateCodeComponent implements OnInit {

    dtOptions: DataTables.Settings = {};
    promoCodeList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    modalRef: BsModalRef;

    sendEmailForm : FormGroup;
    sendSMSForm: FormGroup;

    submitted: boolean = false;
    submitted1: boolean = false;

    constructor(
        public pageTitle: Title,
        private toastr: ToastrService,
        private generateCodeFactory: GenerateCodeService,
        private modalService: BsModalService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Generate VIP Code");
        this.getAllPromoCodes()
    }

    getAllPromoCodes() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.generateCodeFactory
                    .getVIPCodeListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.promoCodeList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "createdAt", searchable: false },
                { data: "promoCode" },
                { data: "", name: "PromoCode.email" },
                { data: "", searchable: false, orderable: false },
                { data: "usedDate", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }


    openSendMailModal(sendemail: TemplateRef<any>, promoCode) {
        this.createSendEmailForm(promoCode)

        this.modalRef = this.modalService.show(sendemail, Object.assign({}, { class: 'modal-lg' }));
        
    }

    createSendEmailForm(promoCode) {
        this.sendEmailForm = new FormGroup({
            'sendEmail': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator, Validators.email]),
            'type': new FormControl('email'),
            'promoCode': new FormControl(promoCode)
        });
    }

    sendEmailSubmit() {
        this.submitted = true
        
        if (this.sendEmailForm.valid) {
            this.generateCodeFactory.sendVIPCode(this.sendEmailForm.value).subscribe(res => {
                let resData = JSON.parse(JSON.stringify(res));
                if (resData.status == 200) {
                    this.toastr.success(resData.message, 'Success');
                    this.modalRef.hide()
                    // this.router.navigate(["/generate-code"]);
                } else {
                    this.toastr.error(resData.message, 'Error');
                }
            }, error => {
                this.toastr.error('Oops! something went wrong', 'Error');
            })
        }

    }

    openSendSMSModal(sendSMS: TemplateRef<any>, promoCode) {
        this.createSendSMSForm(promoCode)

        this.modalRef = this.modalService.show(sendSMS, Object.assign({}, { class: 'modal-lg' }));
    }

    createSendSMSForm(promoCode) {
        this.sendSMSForm = new FormGroup({
            'sendSMS': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'type': new FormControl('sms'),
            'promoCode': new FormControl(promoCode)
        });
    }

    sendSMSSubmit() {
        this.submitted1 = true
        
        if (this.sendSMSForm.valid) {
            this.generateCodeFactory.sendVIPCode(this.sendSMSForm.value).subscribe(res => {
                let resData = JSON.parse(JSON.stringify(res));
                if (resData.status == 200) {
                    this.toastr.success(resData.message, 'Success');
                    this.modalRef.hide()
                    // this.router.navigate(["/generate-code"]);
                } else {
                    this.toastr.error(resData.message, 'Error');
                }
            }, error => {
                this.toastr.error('Oops! something went wrong', 'Error');
            })
        }
    }

}
