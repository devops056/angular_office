import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class GenerateCodeService {
    
    constructor(private http: HttpClient) { }

    addNewVIPCode() {
        return this.http.get(environment.APIURL + "api/addNewVIPCode");
    }

    getVIPCodeListing(data) {
        return this.http.post(environment.APIURL + "api/getVIPCodeListing", data);
    }

    sendVIPCode(data) {
        return this.http.post(environment.APIURL + "api/sendVIPCode", data);
    }

    addNewPromoCode(data) {
        return this.http.post(environment.APIURL + "api/addNewPromoCode", data);
    }

    getPromoCodeListing(data) {
        return this.http.post(environment.APIURL + "api/getPromoCodeListing", data);
    }

    sendPromoCode(data) {
        return this.http.post(environment.APIURL + "api/sendPromoCode", data);
    }


}
