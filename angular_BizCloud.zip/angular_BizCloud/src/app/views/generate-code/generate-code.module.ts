import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GenerateCodeRoutingModule } from './generate-code-routing.module';
import { GenerateCodeComponent } from './generate-code/generate-code.component';
import { AddComponent } from './add/add.component';
import { DataTablesModule } from 'angular-datatables';
import { GenerateCodeService } from './generate-code.services';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { AddPromoComponent } from './add-promo/add-promo.component';
import { PromoCodeListingComponent } from './promo-code-listing/promo-code-listing.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';


@NgModule({
    declarations: [GenerateCodeComponent, AddComponent, AddPromoComponent, PromoCodeListingComponent],
    imports: [
        CommonModule,
        GenerateCodeRoutingModule,
        DataTablesModule,
        FormsModule,
        ReactiveFormsModule,
        ModalModule.forRoot(),
        BsDatepickerModule.forRoot(),
    ],
    providers: [GenerateCodeService]
})
export class GenerateCodeModule { }
