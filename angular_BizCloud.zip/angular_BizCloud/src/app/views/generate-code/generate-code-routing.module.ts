import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GenerateCodeComponent } from './generate-code/generate-code.component';
import { AddComponent } from './add/add.component';
import { AdminAuth } from '../../helpers/adminAuth';
import { PromoCodeListingComponent } from './promo-code-listing/promo-code-listing.component';
import { AddPromoComponent } from './add-promo/add-promo.component';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Generate Code'
        },
        children: [
            {
                path: '',
                redirectTo: 'generate-code'
            },
            {
                path: 'vip-code',
                component: GenerateCodeComponent,
                data: {
                    title: ''
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'vip-code/add',
                component: AddComponent,
                data: {
                    title: 'Add'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'promo-code',
                component: PromoCodeListingComponent,
                data: {
                    title: ''
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'promo-code/add',
                component: AddPromoComponent,
                data: {
                    title: 'Add'
                },
                canActivate: [AdminAuth]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class GenerateCodeRoutingModule { }
