import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContentRoutingModule } from './content-routing.module';
import { ContentComponent } from './content/content.component';
// import { TermsConditionComponent } from './terms-condition/terms-condition.component';
// import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
// import { CustomerServiceComponent } from './customer-service/customer-service.component';
import { DataTablesModule } from 'angular-datatables';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { EditComponent } from './edit/edit.component';
import { ContentService } from './content.services';
import { FormsModule } from '@angular/forms';

@NgModule({
    declarations: [ContentComponent, EditComponent],
    imports: [
        CommonModule,
        ContentRoutingModule,
        DataTablesModule,
        CKEditorModule,
        FormsModule
    ],
    providers: [ContentService]
})
export class ContentModule { }
