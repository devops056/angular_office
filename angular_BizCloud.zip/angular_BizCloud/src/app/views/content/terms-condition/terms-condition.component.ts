import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
    selector: 'app-terms-condition',
    templateUrl: './terms-condition.component.html'
})
export class TermsConditionComponent implements OnInit {

    public Editor = ClassicEditor;

    ckConfig = {
        toolbar: {
            items: [
                'heading',
                '|',
                'bold',
                'italic',
                '|',
                'bulletedList',
                'numberedList',
                '|',
                'insertTable',
                '|',
                'undo',
                'redo'
            ]
        }
    }

    constructor(
        public pageTitle: Title,
        private location: Location
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Terms & Condition");
    }

    goBack() {
        this.location.back();
    }
}
