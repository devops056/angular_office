import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable()
export class ContentService {

    constructor(private http: HttpClient) {
    }

    getAllCMSListing() {
        return this.http.get(environment.APIURL + 'api/getCmsDetails');
    }

    fetchSingleCMSDetails(id) {
        return this.http.get(environment.APIURL + 'api/fetchSingleCMSDetails?id=' + id);
    }

    editCmsDetails(data) {
        return this.http.post(environment.APIURL + 'api/editCmsDetails', data);
    }
}
