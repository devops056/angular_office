import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';

@Component({
    selector: 'app-privacy-policy',
    templateUrl: './privacy-policy.component.html'
})
export class PrivacyPolicyComponent implements OnInit {

    public Editor = ClassicEditor;

    ckConfig = {
        toolbar: {
            items: [
                'heading',
                '|',
                'bold',
                'italic',
                '|',
                'bulletedList',
                'numberedList',
                '|',
                'insertTable',
                '|',
                'undo',
                'redo'
            ]
        }
    }

    constructor(
        public pageTitle: Title,
        private location: Location
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Privacy Policy");
    }

    goBack() {
        this.location.back();
    }

}
