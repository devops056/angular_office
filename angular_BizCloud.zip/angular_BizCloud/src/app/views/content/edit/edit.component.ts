import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { ToastrService } from 'ngx-toastr';
import { ContentService } from '../content.services';
import { Content } from '@angular/compiler/src/render3/r3_ast';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class EditComponent implements OnInit {

    public Editor = ClassicEditor;
    ckeditorContent: string = '';

    ckConfig = {
        toolbar: {
            items: [
                'heading',
                '|',
                'bold',
                'italic',
                '|',
                'bulletedList',
                'numberedList',
                '|',
                'insertTable',
                '|',
                'undo',
                'redo'
            ]
        }
    }

    constructor(
        public pageTitle: Title,
        private location: Location,
        private toastr: ToastrService,
        private contentFactory: ContentService,
        private route: ActivatedRoute,
        private router: Router
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Content");

        // this.ckeditorContent = "<h1>About Us</h1>"
        this.fetchSingleCMSDetails()
    }

    fetchSingleCMSDetails() {
        this.contentFactory.fetchSingleCMSDetails(this.route.snapshot.params.id).subscribe(res => {
            let resData = JSON.parse(JSON.stringify(res));
            if (resData.status == 200 ) {
                this.ckeditorContent = resData.data.description
            } else {
                this.toastr.error(resData.message, 'Error');
            }
        }, err => {
            this.toastr.error('Oops! something went wrong', 'Error');
        })
    }

    goBack() {
        this.location.back();
    }

    onSave() {
        let objToBeSent = {
            "id": this.route.snapshot.params.id,
            "description": this.ckeditorContent
        }

        this.contentFactory.editCmsDetails(objToBeSent).subscribe(res => {
            let resData = JSON.parse(JSON.stringify(res));
            if (resData.status == 200 ) {
                this.toastr.success(resData.message, 'Success');
                this.router.navigate(['/content'])
            } else {
                this.toastr.error(resData.message, 'Error');
            }
        })
    }

}
