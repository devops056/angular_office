import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { ContentService } from '../content.services';

@Component({
    selector: 'app-content',
    templateUrl: './content.component.html'
})
export class ContentComponent implements OnInit {

    dtOptions: DataTables.Settings = {
        "searching": false,
        "lengthChange": false
    };

    CMSData = []

    constructor(
        public pageTitle: Title,
        private contentFactory: ContentService,
        private toastr: ToastrService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Content");
        this.fetchCMS()
    }

    fetchCMS() {
        this.contentFactory.getAllCMSListing().subscribe(res => {
            let resData = JSON.parse(JSON.stringify(res));
            if (resData.status == 200 ) {
                this.CMSData = resData.data.getCmsData
            } else {
                this.toastr.error(resData.message, 'Error');
            }
        }, err => {
            this.toastr.error('Oops! something went wrong', 'Error');
        }, () => {

        })
    }

}
