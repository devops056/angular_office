import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuth } from '../../helpers/adminAuth';
import { ContentComponent } from './content/content.component';
// import { TermsConditionComponent } from './terms-condition/terms-condition.component';
// import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
// import { CustomerServiceComponent } from './customer-service/customer-service.component';
import { EditComponent } from './edit/edit.component';

const routes: Routes = [
	{
        path: '',
        data: {
            title: 'Content'
        },
        children: [
            {
                path: '',
                component: ContentComponent,
                data: {
                    title: ''
                },
                canActivate: [AdminAuth]
            },
            // {
            //     path: 'terms-condition',
            //     component: TermsConditionComponent,
            //     data: {
            //         title: 'Terms & Condition'
            //     }
            // },
            {
                path: 'edit/:id',
                component: EditComponent,
                data: {
                    title: 'Edit Content'
                },
                canActivate: [AdminAuth]
            },
            // {
            //     path: 'privacy-policy',
            //     component: PrivacyPolicyComponent,
            //     data: {
            //         title: 'Privacy Policy'
            //     }
            // },

            // {
            //     path: 'customer-service',
            //     component: CustomerServiceComponent,
            //     data: {
            //         title: 'Customer Service'
            //     }
            // }
        ]
    }
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class ContentRoutingModule { }
