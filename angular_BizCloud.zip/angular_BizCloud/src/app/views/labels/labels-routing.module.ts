import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MatchedComponent } from './matched/matched.component';
import { MatchedAddComponent } from './matched/add/add.component';
import { MatchedEditComponent } from './matched/edit/edit.component';
import { SelfMatchedComponent } from './selfmatched/selfmatched.component';
import { SelfAddComponent } from './selfmatched/add/add.component';
import { SelfEditComponent } from './selfmatched/edit/edit.component';
import { PreferenceComponent } from './preference/preference.component';
import { PreferenceAddComponent } from './preference/add/add.component';
import { PreferenceEditComponent } from './preference/edit/edit.component';
import { IndustryComponent } from './industry/industry.component';
import { IndustryAddComponent } from './industry/add/add.component';
import { IndustryEditComponent } from './industry/edit/edit.component';
import { ExpertiseComponent } from './expertise/expertise.component';
import { ExpertiseAddComponent } from './expertise/add/add.component';
import { ExpertiseEditComponent } from './expertise/edit/edit.component';
import { AdminAuth } from '../../helpers/adminAuth';
import { GroupComponent } from './group/group.component';
import { GroupAddComponent } from './group/add/add.component';
import { GroupEditComponent } from './group/edit/edit.component';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Labels'
        },
        children: [
            {
                path: '',
                redirectTo: 'matched'
            },
            {
                path: 'matched',
                component: MatchedComponent,
                data: {
                    title: 'Matched'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'matched/add',
                component: MatchedAddComponent,
                data: {
                    title: 'Add Matched'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'matched/edit/:pairedId',
                component: MatchedEditComponent,
                data: {
                    title: 'Edit Matched'
                },
                canActivate: [AdminAuth]
            },

            {
                path: 'selfmatched',
                component: SelfMatchedComponent,
                data: {
                    title: 'Self Matched'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'selfmatched/add',
                component: SelfAddComponent,
                data: {
                    title: 'Add Self Matched'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'selfmatched/edit/:selfMatchedId',
                component: SelfEditComponent,
                data: {
                    title: 'Edit Self Matched'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'preference',
                component: PreferenceComponent,
                data: {
                    title: 'Preference'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'preference/add',
                component: PreferenceAddComponent,
                data: {
                    title: 'Add Preference'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'preference/edit/:preferencesId',
                component: PreferenceEditComponent,
                data: {
                    title: 'Edit Preference'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'industry',
                component: IndustryComponent,
                data: {
                    title: 'Industry'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'industry/add',
                component: IndustryAddComponent,
                data: {
                    title: 'Add Industry'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'industry/edit/:industryId',
                component: IndustryEditComponent,
                data: {
                    title: 'Edit Industry'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'expertise',
                component: ExpertiseComponent,
                data: {
                    title: 'Expertise'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'expertise/add',
                component: ExpertiseAddComponent,
                data: {
                    title: 'Add Expertise'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'expertise/edit/:expertiseId',
                component: ExpertiseEditComponent,
                data: {
                    title: 'Edit Expertise'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'user-group',
                component: GroupComponent,
                data: {
                    title: 'User Group'
                }
            },
            {
                path: 'user-group/add',
                component: GroupAddComponent,
                data: {
                    title: 'Add User Group'
                }
            },
            {
                path: 'user-group/edit/:groupId',
                component: GroupEditComponent,
                data: {
                    title: 'Edit User Group'
                }
            },
        ]
    }
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LabelsRoutingModule { }
