import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class LabelService {
    constructor(private http: HttpClient) { }

    addPreferences(data) {
        return this.http.post(environment.APIURL + "api/addPreferences", data);
    }

    getAllPrefrences(data) {
        return this.http.post(environment.APIURL + "api/getAllPrefrences", data);
    }

    activeInActivePrefrences(data) {
        return this.http.post(environment.APIURL + "api/activeInActivePrefrences", data);
    }

    getPrefrenceDetail(preferencesId) {
        return this.http.get(environment.APIURL + "api/getPrefrenceDetail?prefrenceId=" + preferencesId);
    }

    editPrefrences(data) {
        return this.http.post(environment.APIURL + "api/editPrefrences", data);
    }

    addExpertise(data) {
        return this.http.post(environment.APIURL + "api/addExpertise", data);
    }

    getAllExpertise(data) {
        return this.http.post(environment.APIURL + "api/getAllExpertise", data);
    }

    activeInActiveExpertise(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveExpertise", data);
    }

    getExpertiseDetail(expertiseId) {
        return this.http.get(environment.APIURL + "api/getExpertiseDetail?expertiseId=" + expertiseId);
    }

    editExpertise(data) {
        return this.http.post(environment.APIURL + "api/editExpertise", data);
    }

    addSelfMatched(data) {
        return this.http.post(environment.APIURL + "api/addSelfMatched", data);
    }

    fetchAllSelfMatched(data) {
        return this.http.post(environment.APIURL + "api/fetchAllSelfMatched", data);
    }

    getSelfMatchedDetails(selfMatchId) {
        return this.http.get(environment.APIURL + "api/getSelfMatchedDetails?selfMatchId=" + selfMatchId);
    }

    editSelfMatched(data) {
        return this.http.post(environment.APIURL + "api/editSelfMatched", data);
    }

    activeInActiveSelfMatched(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveSelfMatched", data);
    }

    addPaired(data) {
        return this.http.post(environment.APIURL + 'api/addPaired', data);
    }

    getPairedGoalsListing(data){
        return this.http.post(environment.APIURL + 'api/getPairedGoalsListing', data);
    }

    activeInActivePairedGoal(data) {
        return this.http.post(environment.APIURL + "api/activeInActivePairedGoal", data);
    }

    getPairedDetails(pairedId) {
        return this.http.get(environment.APIURL + "api/getPairedDetails?pairedId=" + pairedId);
    }

    editPairedGoal(data) {
        return this.http.post(environment.APIURL + "api/editPairedGoal", data);
    }

    addIndustry(data) {
        return this.http.post(environment.APIURL + 'api/addIndustry', data);
    }

    getAllIndustryListing(data){
        return this.http.post(environment.APIURL + 'api/getAllIndustryListing', data);
    }

    activeInActiveIndustry(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveIndustry", data);
    }

    getIndustryDetails(industryId) {
        return this.http.get(environment.APIURL + "api/getIndustryDetails?industryId=" + industryId);
    }

    editIndustry(data) {
        return this.http.post(environment.APIURL + "api/editIndustry", data);
    }
    
    getAllUserGroupListing(data){
        return this.http.post(environment.APIURL + 'api/getAllUserGroupListing', data);
    }

    addUserGroup(data) {
        return this.http.post(environment.APIURL + 'api/addUserGroup', data);
    }

    getUserGroupDetails(groupId) {
        return this.http.get(environment.APIURL + "api/getUserGroupDetails?groupId=" + groupId);
    }

    editUserGroup(data) {
        return this.http.post(environment.APIURL + "api/editUserGroup", data);
    }

    activeInActiveUserGroup(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveUserGroup", data);
    }

}
