import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class PreferenceEditComponent implements OnInit {

    editPreferencesForm: FormGroup;
    submitted: boolean = false;
    preferencesId: string = "";
    preferencesDetails: any = {};

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute,
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Preference Edit");
        this.route.params.subscribe(params => {
            this.preferencesId = params.preferencesId;
        });
        this.createForm();
        this.getPreferencesDetails();
    }

    createForm() {
        this.editPreferencesForm = new FormGroup({
            'prefrences': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator])
        });
    }

    getPreferencesDetails() {
        this.labelFactory.getPrefrenceDetail(this.preferencesId).subscribe(
            response => {
                let getPreferencesDetails = JSON.parse(JSON.stringify(response));
                if (getPreferencesDetails.status == 200) {
                    this.preferencesDetails = getPreferencesDetails.data;
                    this.editPreferencesForm.patchValue({
                        "prefrences": this.preferencesDetails.en
                    });
                } else {
                    this.preferencesDetails = {};
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    editPreferencesFormSubmit() {
        this.submitted = true;
        if (this.editPreferencesForm.valid) {
            this.labelFactory.editPrefrences({ "prefrenceId": this.preferencesId, "prefrences": this.editPreferencesForm.value.prefrences }).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/labels/preference'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }
}
