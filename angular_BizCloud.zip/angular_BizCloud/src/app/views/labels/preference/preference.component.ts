import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { LabelService } from '../labels.services';
import swal from 'sweetalert2'

@Component({
    selector: 'app-preference',
    templateUrl: './preference.component.html'
})
export class PreferenceComponent implements OnInit, AfterViewInit, OnDestroy {

    dtOptions: DataTables.Settings = {};
    preferencesList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    constructor(
        public pageTitle: Title,
        private labelFactory: LabelService,
        private toastr: ToastrService,
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Preference");
        this.getAllPrefrences();
    }

    getAllPrefrences() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.labelFactory
                    .getAllPrefrences(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.preferencesList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "en" },
                { data: "updatedAt", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    changedPreferencesStatus(prefrenceId, type) {
        let text = "You want to activate this preference?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Preference has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this preference?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Preference has been deactivated.";
        }
        swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.labelFactory.activeInActivePrefrences({ "prefrenceId": prefrenceId, "status": type }).subscribe(
                    response => {
                        swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }
}
