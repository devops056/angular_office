import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { LabelService } from '../labels.services';
import swal from 'sweetalert2'

@Component({
    selector: 'app-matched',
    templateUrl: './matched.component.html'
})
export class MatchedComponent implements OnInit, AfterViewInit, OnDestroy {

    dtOptions: DataTables.Settings = {};
    pairedGoals: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    active: boolean = true;
    inactive: boolean = false;

    constructor(
        public pageTitle: Title,
        private toastr: ToastrService,
        private labelFactory: LabelService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Matched");
        this.getAllPairedGoals();
    }

    getAllPairedGoals(){
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.labelFactory
                    .getPairedGoalsListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.pairedGoals = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "name" },
                // { data: "firstName" },
                { data: "updatedAt", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    changeGoalStatus(prefrenceId, type) {
        let text = "You want to activate this paired goal?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Paired goal has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this paired goal?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Paired goal has been deactivated.";
        }
        swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.labelFactory.activeInActivePairedGoal({ "pairedGoalId": prefrenceId, "status": type }).subscribe(
                    response => {
                        swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }
}
