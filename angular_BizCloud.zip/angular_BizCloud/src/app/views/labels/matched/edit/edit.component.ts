import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class MatchedEditComponent implements OnInit {

    editPairedForm : FormGroup;
    submitted: boolean = false;

    pairedId: string = "";
    pairedDetails: any = {};
    itemsList = []

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute,
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Paired Edit");
        this.route.params.subscribe(params => {
            this.pairedId = params.pairedId;
        });
        this.createForm();
        this.getPairedDetails();
    }

    createForm() {
        this.editPairedForm = new FormGroup({
            'key': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'values': new FormControl('', [Validators.required])
        });
    }

    getPairedDetails() {
        this.labelFactory.getPairedDetails(this.pairedId).subscribe(
            response => {
                let getPairedDetails = JSON.parse(JSON.stringify(response));
                if (getPairedDetails.status == 200) {
                    this.pairedDetails = getPairedDetails.data;
                    this.editPairedForm.patchValue({
                        "key": this.pairedDetails.name,
                        "values": this.pairedDetails.subGoalData
                    });
                    // this.itemsList = obj
                } else {
                    this.pairedDetails = {};
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    editPairedFormSubmit() {
        this.submitted = true;
        if (this.editPairedForm.valid) {
            this.labelFactory.editPairedGoal({ "pairedId": this.pairedId, "key": this.editPairedForm.value.key, "values": this.editPairedForm.value.values }).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/labels/matched'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }
}
