import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LabelsRoutingModule } from './labels-routing.module';
import { MatchedComponent } from './matched/matched.component';
import { SelfMatchedComponent } from './selfmatched/selfmatched.component';
import { PreferenceComponent } from './preference/preference.component';
import { IndustryComponent } from './industry/industry.component';
import { ExpertiseComponent } from './expertise/expertise.component';
import { DataTablesModule } from 'angular-datatables';
import { MatchedAddComponent } from './matched/add/add.component';
import { MatchedEditComponent } from './matched/edit/edit.component';
import { SelfAddComponent } from './selfmatched/add/add.component';
import { SelfEditComponent } from './selfmatched/edit/edit.component';
import { PreferenceAddComponent } from './preference/add/add.component';
import { PreferenceEditComponent } from './preference/edit/edit.component';
import { IndustryAddComponent } from './industry/add/add.component';
import { IndustryEditComponent } from './industry/edit/edit.component';
import { ExpertiseAddComponent } from './expertise/add/add.component';
import { ExpertiseEditComponent } from './expertise/edit/edit.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReactiveFormsModule } from '@angular/forms';
import { LabelService } from './labels.services';
import { GroupComponent } from './group/group.component';
import { GroupAddComponent } from './group/add/add.component';
import { GroupEditComponent } from './group/edit/edit.component';


@NgModule({
    declarations: [
        MatchedComponent,
        SelfMatchedComponent,
        PreferenceComponent,
        IndustryComponent,
        ExpertiseComponent,
        MatchedAddComponent,
        MatchedEditComponent,
        SelfAddComponent,
        SelfEditComponent,
        PreferenceAddComponent,
        PreferenceEditComponent,
        IndustryAddComponent,
        IndustryEditComponent,
        ExpertiseAddComponent,
        ExpertiseEditComponent,
        GroupComponent,
        GroupAddComponent,
        GroupEditComponent
    ],
    imports: [
        CommonModule,
        LabelsRoutingModule,
        DataTablesModule,
        NgSelectModule,
        ReactiveFormsModule
    ],
    providers: [LabelService]
})
export class LabelsModule { }
