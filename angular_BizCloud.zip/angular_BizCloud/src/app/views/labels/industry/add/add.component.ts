import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-add',
    templateUrl: './add.component.html'
})
export class IndustryAddComponent implements OnInit {

    addIndustryForm : FormGroup;
    submitted: boolean = false;


    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private toastr: ToastrService,
        private router: Router
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Industry Add");
        this.createForm();
    }

    createForm() {
        this.addIndustryForm = new FormGroup({
            'industry': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'subIndustry': new FormControl('', [Validators.required])
        });
    }

    addIndustryFormSubmit() {
        this.submitted = true;
        if (this.addIndustryForm.valid) {
            this.labelFactory.addIndustry(this.addIndustryForm.value).subscribe(
                response => {
                    let resData = JSON.parse(JSON.stringify(response));
                    if (resData.status == 200) {
                        this.toastr.success(resData.message, 'Success');
                        this.router.navigate(["/labels/industry"]);
                    } else {
                        this.toastr.error(resData.message, 'Error');
                    }
                },
                error => {
                    this.toastr.error('Oops! something went wrong', 'Error');
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }

}
