import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class IndustryEditComponent implements OnInit {

    editIndustryForm : FormGroup;
    submitted: boolean = false;

    industryId: string = "";
    industryDetails: any = {};
    itemsList = []

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute,
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Industry Edit");
        this.route.params.subscribe(params => {
            this.industryId = params.industryId;
        });
        this.createForm();
        this.getIndustryDetails();
    }

    createForm() {
        this.editIndustryForm = new FormGroup({
            'industry': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'subIndustry': new FormControl('', [Validators.required])
        });
    }

    getIndustryDetails() {
        this.labelFactory.getIndustryDetails(this.industryId).subscribe(
            response => {
                let getPairedDetails = JSON.parse(JSON.stringify(response));
                if (getPairedDetails.status == 200) {
                    this.industryDetails = getPairedDetails.data;
                    this.editIndustryForm.patchValue({
                        "industry": this.industryDetails.name,
                        "subIndustry": this.industryDetails.industryData
                    });
                    // this.itemsList = obj
                } else {
                    this.industryDetails = {};
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    editIndustryFormSubmit() {
        this.submitted = true;
        if (this.editIndustryForm.valid) {
            this.labelFactory.editIndustry({ "industryId": this.industryId, "industry": this.editIndustryForm.value.industry, "subIndustry": this.editIndustryForm.value.subIndustry }).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/labels/industry'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }
}
