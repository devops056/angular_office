import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { LabelService } from '../labels.services';
import swal from 'sweetalert2'

@Component({
    selector: 'app-industry',
    templateUrl: './industry.component.html'
})
export class IndustryComponent implements OnInit {
    
    dtOptions: DataTables.Settings = {};
    industries: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    active: boolean = true;
    inactive: boolean = false;

    constructor(
        public pageTitle: Title,
        private toastr: ToastrService,
        private labelFactory: LabelService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Industry");
        this.getAllIndustry()
    }

    getAllIndustry(){
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.labelFactory
                    .getAllIndustryListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.industries = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "name" },
                // { data: "firstName" },
                { data: "updatedAt", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    changeIndustryStatus(industryId, type) {
        let text = "You want to activate this industry?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Industry has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this industry?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Industry has been deactivated.";
        }
        swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.labelFactory.activeInActiveIndustry({ "industryId": industryId, "status": type }).subscribe(
                    response => {
                        swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

}
