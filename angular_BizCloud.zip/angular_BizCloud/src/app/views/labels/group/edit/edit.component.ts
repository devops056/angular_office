import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class GroupEditComponent implements OnInit {

    editUserGroupForm : FormGroup;
    submitted: boolean = false;

    groupId: string = "";
    userGroupDetails: any = {};
    itemsList = []

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute,
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Edit User Group");
        this.route.params.subscribe(params => {
            this.groupId = params.groupId;
        });
        this.createForm();
        this.getUserGroupDetails();
    }

    createForm() {
        this.editUserGroupForm = new FormGroup({
            'userGroup': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'subUserGroup': new FormControl('', [Validators.required])
        });
    }

    getUserGroupDetails() {
        this.labelFactory.getUserGroupDetails(this.groupId).subscribe(
            response => {
                let getPairedDetails = JSON.parse(JSON.stringify(response));
                if (getPairedDetails.status == 200) {
                    this.userGroupDetails = getPairedDetails.data;
                    this.editUserGroupForm.patchValue({
                        "userGroup": this.userGroupDetails.name,
                        "subUserGroup": this.userGroupDetails.userGroupData
                    });
                    // this.itemsList = obj
                } else {
                    this.userGroupDetails = {};
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    editGroupFormSubmit() {
        this.submitted = true;
        if (this.editUserGroupForm.valid) {
            this.labelFactory.editUserGroup({ "groupId": this.groupId, "userGroup": this.editUserGroupForm.value.userGroup, "subUserGroup": this.editUserGroupForm.value.subUserGroup }).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/labels/user-group'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }
}
