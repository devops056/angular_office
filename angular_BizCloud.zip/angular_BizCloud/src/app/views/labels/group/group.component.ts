import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { LabelService } from '../labels.services';
import swal from 'sweetalert2'

@Component({
    selector: 'app-group',
    templateUrl: './group.component.html'
})
export class GroupComponent implements OnInit {
    
    dtOptions: DataTables.Settings = {};
    userGroups: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    active: boolean = true;
    inactive: boolean = false;

    constructor(
        public pageTitle: Title,
        private toastr: ToastrService,
        private labelFactory: LabelService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - User Group");
        this.getAllUserGroup()
    }

    getAllUserGroup(){
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.labelFactory
                    .getAllUserGroupListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.userGroups = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "name" },
                // { data: "firstName" },
                { data: "updatedAt", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    changeUserGroupStatus(groupId, type) {
        let text = "You want to activate this user group?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "User group has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this user group?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "User group has been deactivated.";
        }
        swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.labelFactory.activeInActiveUserGroup({ "groupId": groupId, "status": type }).subscribe(
                    response => {
                        swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

}
