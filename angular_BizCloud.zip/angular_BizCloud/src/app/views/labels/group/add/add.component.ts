import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-add',
    templateUrl: './add.component.html'
})
export class GroupAddComponent implements OnInit {

    addGroupForm : FormGroup;
    submitted: boolean = false;


    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private toastr: ToastrService,
        private router: Router
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Add User Group");
        this.createForm();
    }

    createForm() {
        this.addGroupForm = new FormGroup({
            'userGroup': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'subUserGroup': new FormControl('', [Validators.required])
        });
    }

    addGroupFormSubmit() {
        this.submitted = true;
        if (this.addGroupForm.valid) {
            this.labelFactory.addUserGroup(this.addGroupForm.value).subscribe(
                response => {
                    let resData = JSON.parse(JSON.stringify(response));
                    if (resData.status == 200) {
                        this.toastr.success(resData.message, 'Success');
                        this.router.navigate(["/labels/user-group"]);
                    } else {
                        this.toastr.error(resData.message, 'Error');
                    }
                },
                error => {
                    this.toastr.error('Oops! something went wrong', 'Error');
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }

}
