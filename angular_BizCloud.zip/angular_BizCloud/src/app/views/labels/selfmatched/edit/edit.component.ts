import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../../helpers/custom-validators'

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class SelfEditComponent implements OnInit {

    editSelfMatchedForm : FormGroup;
    submitted: boolean = false;
    selfMatchedId: string = "";
    selfMatchedDetails: any = {};

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Paired Edit");
        this.route.params.subscribe(params => {
            this.selfMatchedId = params.selfMatchedId;
        });
        this.createForm();
        this.getSelfMatchedDetails();
    }

    createForm() {
        this.editSelfMatchedForm = new FormGroup({
            'selfMatched': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
        });
    }

    getSelfMatchedDetails() {
        this.labelFactory.getSelfMatchedDetails(this.selfMatchedId).subscribe(
            response => {
                let selfMatchedDetails = JSON.parse(JSON.stringify(response));
                if (selfMatchedDetails.status == 200) {
                    this.selfMatchedDetails = selfMatchedDetails.data;
                    this.editSelfMatchedForm.patchValue({
                        "selfMatched": this.selfMatchedDetails.name
                    });
                } else {
                    this.selfMatchedDetails = {};
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    editSelfMatchedFormSubmit() {
        this.submitted = true;
        if (this.editSelfMatchedForm.valid) {
            this.labelFactory.editSelfMatched({ "selfMatchedId": this.selfMatchedId, "selfMatched": this.editSelfMatchedForm.value.selfMatched }).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/labels/selfmatched'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
        
    }

    goBack() {
        this.location.back();
    }
}
