import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LabelService } from '../../labels.services';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../../helpers/custom-validators'

@Component({
    selector: 'app-add',
    templateUrl: './add.component.html'
})
export class SelfAddComponent implements OnInit {

    addSelfMatchedForm : FormGroup;
    submitted: boolean = false;

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Paired Add");
        this.createForm();
    }

    createForm() {
        this.addSelfMatchedForm = new FormGroup({
            'selfMatched': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
        });
    }

    addSelfMatchedFormSubmit() {
        this.submitted = true;
        if (this.addSelfMatchedForm.valid) {
            this.labelFactory.addSelfMatched(this.addSelfMatchedForm.value).subscribe(
                response => {
                    let resData = JSON.parse(JSON.stringify(response));
                    if (resData.status == 200) {
                        this.toastr.success(resData.message, 'Success');
                        this.router.navigate(["/labels/selfmatched"]);
                    } else {
                        this.toastr.error(resData.message, 'Error');
                    }
                },
                error => {
                    this.toastr.error('Oops! something went wrong', 'Error');
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }

}
