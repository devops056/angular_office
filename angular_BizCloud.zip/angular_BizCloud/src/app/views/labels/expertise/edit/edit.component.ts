import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { LabelService } from '../../labels.services';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../../../../helpers/custom-validators';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class ExpertiseEditComponent implements OnInit {

    editExpertiseForm: FormGroup;
    submitted: boolean = false;
    expertiseId: string = "";
    expertiseDetails: any = {};

    constructor(
        private pageTitle: Title,
        private location: Location,
        private labelFactory: LabelService,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Expertise Edit");
        this.route.params.subscribe(params => {
            this.expertiseId = params.expertiseId;
        });
        this.createForm();
        this.getExpertiseDetails();
    }

    createForm() {
        this.editExpertiseForm = new FormGroup({
            'expertise': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator])
        });
    }

    getExpertiseDetails() {
        this.labelFactory.getExpertiseDetail(this.expertiseId).subscribe(
            response => {
                let getExpertiseDetail = JSON.parse(JSON.stringify(response));
                if (getExpertiseDetail.status == 200) {
                    this.expertiseDetails = getExpertiseDetail.data;
                    this.editExpertiseForm.patchValue({
                        "expertise": this.expertiseDetails.en
                    });
                } else {
                    this.expertiseDetails = {};
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }

    editExpertiseFormSubmit() {
        this.submitted = true;
        if (this.editExpertiseForm.valid) {
            this.labelFactory.editExpertise({ "expertiseId": this.expertiseId, "expertise": this.editExpertiseForm.value.expertise }).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/labels/expertise'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
    }

    goBack() {
        this.location.back();
    }
}
