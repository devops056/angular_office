import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class DashboardService {
    constructor(private http: HttpClient) { }

    fetchDashboard() {
		return this.http.get(environment.APIURL + 'api/dashboard');
    }
    
}
