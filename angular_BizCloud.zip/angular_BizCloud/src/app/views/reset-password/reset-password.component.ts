import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';
import { CusAuthService } from '../../helpers/customauth.services';
import { ToastrService } from 'ngx-toastr';
import { ResetPasswordService } from './reset-password.services';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean = false;

  token;

  isLinkExpired = false
  passChanged = false

  constructor(
    public pageTitle: Title,
    public router: Router,
    public authFactory: CusAuthService,
    private toastr: ToastrService,
    public route: ActivatedRoute,
    private resetPasswordFactory: ResetPasswordService
  ) { }

  ngOnInit(): void {
    this.pageTitle.setTitle("BizCloud - Reset Password");
    
    this.route.params.subscribe(params => {
      this.token = params.resetToken;
    });

    this.createForm()
    this.isTokenExist()
  }

  createForm() {
    this.loginForm = new FormGroup({
      newPassword: new FormControl('', [
        Validators.required,
        Validators.minLength(6), 
        Validators.maxLength(16)
      ]),
      confPassword: new FormControl("", [
        Validators.required
      ])
    })
  }
  
  isTokenExist() {
    this.resetPasswordFactory.checkResetToken({ "token": this.token }).subscribe(res => {
      let tokenDetails = JSON.parse(JSON.stringify(res));
      if (tokenDetails.status == 200) {

      } else {
        this.isLinkExpired = true
      }
    })
  }

  loginFormSubmit() {
    this.submitted = true;
    if (this.loginForm.valid && this.loginForm.value.newPassword == this.loginForm.value.confPassword) {
      this.resetPasswordFactory.resetPassword(this.token, this.loginForm.value).subscribe(
        response => {
          let adminDetails = JSON.parse(JSON.stringify(response));
          if (adminDetails.status == 200) {
            this.passChanged = true
            // this.toastr.success(adminDetails.message, 'Error');
            // this.loginForm.patchValue({
            //   newPassword: '',
            //   confPassword: ''
            // })
          } else {
            this.toastr.error(adminDetails.message, 'Error');
          }
        },
        error => {
          this.toastr.error(
            "Oops! Something went wrong",
            "Error",
          );
        }
      );
    }
  }

}
