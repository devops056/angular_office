import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ResetPasswordComponent } from './reset-password.component';
import { ResetPasswordRoutingModule } from './reset-password.routing.module';
import { ResetPasswordService } from './reset-password.services'

@NgModule({
    declarations: [ResetPasswordComponent],
    imports: [
        CommonModule,
        ResetPasswordRoutingModule,
        FormsModule,
        ReactiveFormsModule
    ],
    providers: [ResetPasswordService]
})
export class ResetPasswordModule { }
