import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class ResetPasswordService {
    constructor(private http: HttpClient) { }

    resetPassword(token, data) {
        return this.http.post(environment.BASEURLV1 + "auth/resetpassword/" + token, data);
    }

    checkResetToken(data) {
        return this.http.post(environment.BASEURLV1 + "auth/checkResetToken", data);
    }

    
}
