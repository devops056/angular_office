import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserRoleService } from '../user-role.services';
import { CustomValidators } from '../../../helpers/custom-validators';

@Component({
    selector: 'app-edit',
    templateUrl: './edit.component.html'
})
export class EditComponent implements OnInit {

    adminId;
    addAdminUser: FormGroup;
    submitted: boolean = false;

    navigationData = [];
    adminDetails = [];
    fetchedNavDetails = []

    get navigationFormArray() {
        return this.addAdminUser.controls.checkArray as FormArray;
    }

    constructor(
        public pageTitle: Title,
        private location: Location,
        private router: Router,
        private toastr: ToastrService,
        public route: ActivatedRoute,
        private userRoleFactory: UserRoleService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Edit User Role");
        this.route.params.subscribe(params => {
            this.adminId = params.adminId;
        });

        this.createForm()
        this.fetchAllNavigations()
        this.getAdminDetails()
    }

    createForm() {
        this.addAdminUser = new FormGroup({
            'id': new FormControl(''),
            'emailId': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'confirmEmailId': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator]),
            'checkArray': new FormArray([])
        });
    }

    fetchAllNavigations() {
        this.userRoleFactory.fetchAllNavigationList().subscribe(res => {
            let parsedRes = JSON.parse(JSON.stringify(res));
            if (parsedRes.status == 200) {
                this.navigationData = parsedRes.data
                // this.navigationData.forEach(() => this.navigationFormArray.push(new FormControl(false)));
            }
        })
    }

    getAdminDetails() {
        this.userRoleFactory.fetchAdminUser(this.adminId).subscribe(
            response => {
                let adminData = JSON.parse(JSON.stringify(response));
                if (adminData.status == 200) {
                    this.adminDetails = adminData.data;
                    this.addAdminUser.patchValue({
                        "id": adminData.data.id,
                        "emailId": adminData.data.email,
                        "confirmEmailId": adminData.data.email
                    });
                    this.fetchedNavDetails = adminData.data.permission

                    this.addCheckboxes()
                } else {
                    this.adminDetails = [];
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }


    private addCheckboxes() {
        // console.log('this.navigationData', this.navigationData)
        // console.log("this.navigationFormArray", this.navigationFormArray)

        for (let i = 0; i < this.navigationData.length; i++) {

            if (this.fetchedNavDetails.length == 0) {
                this.navigationFormArray.push(new FormControl(false))
            }

            for (let j = 0; j < this.fetchedNavDetails.length; j++) {

                if (this.navigationData[i].id == this.fetchedNavDetails[j].id) {
                    this.navigationFormArray.push(new FormControl(true))
                    break;
                }

                if (j == this.fetchedNavDetails.length - 1) {
                    this.navigationFormArray.push(new FormControl(false))
                }
            }
        }

    }


    updateAdminUserSubmit() {
        const selectedOrderIds = this.addAdminUser.value.checkArray
            .map((checked, i) => checked ? this.navigationData[i].id : null)
            .filter(v => v !== null);

        let dataToBeSent = {
            "id": this.addAdminUser.value.id,
            "emailId": this.addAdminUser.value.emailId,
            "selectedPermission": selectedOrderIds
        }

        // console.log(dataToBeSent)

        this.submitted = true;
        if (this.addAdminUser.valid) {
            this.userRoleFactory.updateAdminUser(dataToBeSent).subscribe(
                response => {
                    let finalRes = JSON.parse(JSON.stringify(response));
                    if (finalRes.status == 200) {
                        this.toastr.success(finalRes.message, "Success")
                        this.router.navigate(['/user-role'])
                    } else {
                        this.toastr.error(finalRes.message, "Error")
                    }
                },
                error => {
                    this.toastr.error("Oops! Something went wrong!", "Error")
                }
            );
        }
    }


    goBack() {
        this.location.back();
    }

}
