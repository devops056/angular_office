import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import Swal from 'sweetalert2';
import { UserRoleService } from '../user-role.services';
import { ToastrService } from 'ngx-toastr';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import swal from 'sweetalert2'

@Component({
    selector: 'app-user-role',
    templateUrl: './user-role.component.html'
})
export class UserRoleComponent implements OnInit {

    dtOptions: DataTables.Settings = {};
    adminList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    constructor(
        public pageTitle: Title,
        private userRoleFactory: UserRoleService,
        private toastr: ToastrService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - User Role");
        this.getAllAdmin()
    }

    getAllAdmin(){
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.userRoleFactory
                    .fetchAllAdminList(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.adminList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "email" },
                { data: "updatedAt", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }
       

    changeAdminStatus(adminId, type) {
        let text = "You want to activate this admin?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Admin has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this admin?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Admin has been deactivated.";
        }
        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.userRoleFactory.activeInActiveAdmin({ "adminId": adminId, "status": type }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

}
