import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserRoleComponent } from './user-role/user-role.component';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { AdminAuth } from '../../helpers/adminAuth';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'User Role'
        },
        children: [
            {
                path: '',
                redirectTo: 'user-role'
            },
            {
                path: '',
                component: UserRoleComponent,
                data: {
                    title: ''
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'add',
                component: AddComponent,
                data: {
                    title: 'Add'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'edit/:adminId',
                component: EditComponent,
                data: {
                    title: 'Edit'
                },
                canActivate: [AdminAuth]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class UserRoleRoutingModule { }
