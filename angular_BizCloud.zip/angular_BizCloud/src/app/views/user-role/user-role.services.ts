import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class UserRoleService {

    constructor(private http: HttpClient) { }

    fetchAllNavigationList() {
        return this.http.get(environment.APIURL + "api/fetchAllNavigationList");
    }

    addAdminUser(data) {
        return this.http.post(environment.APIURL + "api/addAdminUser", data);
    }

    activeInActiveAdmin(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveAdmin", data);
    }

    fetchAdminUser(adminId) {
        return this.http.get(environment.APIURL + "api/fetchAdminUser?adminId=" + adminId);
    }

    updateAdminUser(data) {
        return this.http.post(environment.APIURL + "api/updateAdminUser", data);
    }

    fetchAllAdminList(data) {
        return this.http.post(environment.APIURL + "api/fetchAllAdminList", data);
    }

}
