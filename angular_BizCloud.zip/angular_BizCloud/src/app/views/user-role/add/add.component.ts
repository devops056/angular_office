import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomValidators } from '../../../helpers/custom-validators';
import { UserRoleService } from '../user-role.services';

@Component({
    selector: 'app-add',
    templateUrl: './add.component.html'
})
export class AddComponent implements OnInit {

    addAdminUser: FormGroup;
    submitted: boolean = false;

    navigationData = [];

    get navigationFormArray() {
        return this.addAdminUser.controls.checkArray as FormArray;
    }

    constructor(
        public pageTitle: Title,
        private location: Location,
        private router: Router,
        private toastr: ToastrService,
        private userRoleFactory: UserRoleService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Add User Role");
        this.createForm()
        this.fetchAllNavigations()
    }

    createForm() {
        this.addAdminUser = new FormGroup({
            'emailId': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator, Validators.email]),
            'confirmEmailId': new FormControl('', [Validators.required, CustomValidators.noWhitespaceValidator, Validators.email]),
            'checkArray': new FormArray([])
        });
        // this.addCheckboxes()
    }

    fetchAllNavigations() {
        this.userRoleFactory.fetchAllNavigationList().subscribe(res => {
            let parsedRes = JSON.parse(JSON.stringify(res));
            if (parsedRes.status == 200) {
                this.navigationData = parsedRes.data
                this.navigationData.forEach(() => this.navigationFormArray.push(new FormControl(false)));
            }
        })
    }

    addAdminUserSubmit() {
        const selectedOrderIds = this.addAdminUser.value.checkArray
            .map((checked, i) => checked ? this.navigationData[i].id : null)
            .filter(v => v !== null);

        let dataToBeSent = {
            "emailId": this.addAdminUser.value.emailId,
            "selectedPermission": selectedOrderIds
        }

        this.submitted = true;
        if (this.addAdminUser.valid) {
            this.userRoleFactory.addAdminUser(dataToBeSent).subscribe(res => {
                let finalRes = JSON.parse(JSON.stringify(res));

                if (finalRes.status == 200) {
                    this.toastr.success(finalRes.message, "Success")
                    this.router.navigate(['/user-role'])
                } else {
                    this.toastr.error(finalRes.message, "Error")
                }

            }, error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            })
        }

    }

    goBack() {
        this.location.back();
    }

}
