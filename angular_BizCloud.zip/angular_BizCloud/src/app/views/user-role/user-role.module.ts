import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoleRoutingModule } from './user-role-routing.module';
import { UserRoleComponent } from './user-role/user-role.component';
import { AddComponent } from './add/add.component';
import { DataTablesModule } from 'angular-datatables';
import { EditComponent } from './edit/edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserRoleService } from './user-role.services';

@NgModule({
    declarations: [UserRoleComponent, AddComponent, EditComponent],
    imports: [
        CommonModule,
        UserRoleRoutingModule,
        DataTablesModule,
        FormsModule,
        ReactiveFormsModule
    ],
    providers: [UserRoleService]
})
export class UserRoleModule { }
