import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MomentsComponent } from './moments/moments.component';
import { PostComponent } from './post/post.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';
import { CommentComponent } from './comment/comment.component';
import { AdminAuth } from '../../helpers/adminAuth';
import { ArticleComponent } from './article/article.component';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Moments'
        },
        children: [
            {
                path: '',
                redirectTo: 'moments'
            },
            {
                path: 'moments',
                component: MomentsComponent,
                data: {
                    title: 'Moments'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'post',
                component: PostComponent,
                data: {
                    title: 'Post'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'advertisement',
                component: AdvertisementComponent,
                data: {
                    title: 'Advertisement'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'article',
                component: ArticleComponent,
                data: {
                    title: 'Article'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'comment',
                component: CommentComponent,
                data: {
                    title: 'Comment'
                },
                canActivate: [AdminAuth]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class MomentsRoutingModule { }
