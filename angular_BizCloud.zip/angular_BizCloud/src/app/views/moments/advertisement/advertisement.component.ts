import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import Swal from 'sweetalert2';
import { environment } from '../../../../environments/environment';
import { MomentsService } from '../moments.services';

@Component({
    selector: 'app-advertisement',
    templateUrl: './advertisement.component.html'
})
export class AdvertisementComponent implements OnInit {

    dtOptions: DataTables.Settings = {};
    postList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    modalRef: BsModalRef;

    adDetails;

    baseURLPathProfile = environment.GETIMGFOLDER + "profile/"
    baseURLPathImg = environment.GETIMGFOLDER + "post/image/"

    constructor(
        public pageTitle: Title,
        private modalService: BsModalService,
        private toastr: ToastrService,
        private momentFactory: MomentsService
    ) { }

    detailsModal(details: TemplateRef<any>, id) {
        this.modalRef = this.modalService.show(details, {
            class: 'modal-dialog-centered modal-lg'
        });

        this.momentFactory.getAdvertisementDetails(id).subscribe(
            response => {
                let parsedAdDetails = JSON.parse(JSON.stringify(response));
                if (parsedAdDetails.status == 200) {
                    this.adDetails = parsedAdDetails.data
                } else {
                    this.adDetails = [];
                }
            },
            error => {
                this.toastr.error("Oops! Something went wrong!", "Error")
            }
        );
    }


    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud -  Moments Advertisement");
        this.getAllAdvertisement()
    }

    getAllAdvertisement() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.momentFactory
                    .getAllAdvertisementListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.postList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "createdAt", searchable: false },
                { data: "text" },
                { data: "", name: "userDetails.firstName" },
                { data: "reports", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

    changeAdStatus(adId, type) {
        let text = "You want to activate this advertisement?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Advertisement has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this advertisement?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Advertisement has been deactivated.";
        }
        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.momentFactory.activeInActiveAdvertisement({ "adId": adId, "status": type }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    userImgErr(event) {
        event.target.src = environment.PLACEHOLDERIMG
    }
}
