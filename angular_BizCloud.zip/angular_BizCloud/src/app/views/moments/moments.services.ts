import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { environment } from '../../../environments/environment';

@Injectable()
export class MomentsService {

    constructor(private http: HttpClient) { }

    getAllPosts(data) {
        return this.http.post(environment.APIURL + "api/getAllPostListing", data);
    }

    activeInActivePost(data) {
        return this.http.post(environment.APIURL + "api/activeInActivePost", data);
    }

    getAllMoments(data) {
        return this.http.post(environment.APIURL + "api/getAllMomentsListing", data);
    }

    getPostDetails(postId) {
        return this.http.get(environment.APIURL + "api/getPostDetails?postId=" + postId);
    }

    getAllAdvertisementListing(data) {
        return this.http.post(environment.APIURL + "api/getAllAdvertisementListing", data);
    }

    activeInActiveAdvertisement(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveAdvertisement", data);
    }

    getAdvertisementDetails(adId) {
        return this.http.get(environment.APIURL + "api/getAdvertisementDetails?adId=" + adId);
    }

    getAllArticles(data) {
        return this.http.post(environment.APIURL + "api/getAllArticles", data);
    }
    
    activeInActiveArticle(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveArticle", data);
    }

    getAllReportCommentListing(data) {
        return this.http.post(environment.APIURL + "api/getAllReportCommentListing", data);
    }

    activeInActiveReportedComment(data) {
        return this.http.post(environment.APIURL + "api/activeInActiveReportedComment", data);
    }

    resolveReportedComment(data) {
        return this.http.post(environment.APIURL + "api/resolveReportedComment", data);
    }

}
