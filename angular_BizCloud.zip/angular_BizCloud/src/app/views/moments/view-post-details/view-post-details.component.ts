import { Component, Input, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { MomentsService } from '../moments.services';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-view-post-details',
  templateUrl: './view-post-details.component.html',
  styleUrls: ['./view-post-details.component.scss']
})
export class ViewPostDetailsComponent implements OnInit {

  @Input() postId;

  baseURLPathProfile = environment.GETIMGFOLDER + "profile/"
  baseURLPathImg = environment.GETIMGFOLDER + "post/image/"
  baseURLPathVideo = environment.GETIMGFOLDER + "post/video/"

  postDetails;

  slides = [];

  type;

  slideConfig = { "slidesToShow": 1, "slidesToScroll": 1 };

  constructor(
    private modalService: BsModalService,
    public modalRef: BsModalRef,
    private momentFactory: MomentsService
  ) { }

  ngOnInit(): void {
    this.momentFactory.getPostDetails(this.postId).subscribe(res => {
      let getPostDetails = JSON.parse(JSON.stringify(res))

      if (getPostDetails.status == 200) {
        this.postDetails = getPostDetails.data;

        if (this.postDetails.PostMedias.length > 0) {
          if (this.postDetails.PostMedias[0].mediaType == 'image') {
            for (let postImg of this.postDetails.PostMedias) {
              this.slides.push({ "img": this.baseURLPathImg + postImg.mediaFile })
            }
          } else {

          }
        }

      } else {
        this.postDetails = [];
      }

    })
  }

  onClose() {
    this.modalRef.hide()
  }

  userImgErr(event) {
    event.target.src = environment.PLACEHOLDERIMG
  }

}
