import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import Swal from 'sweetalert2';
import { MomentsService } from '../moments.services';
import { ViewPostDetailsComponent } from '../view-post-details/view-post-details.component';

@Component({
    selector: 'app-post',
    templateUrl: './post.component.html'
})
export class PostComponent implements OnInit {

    modalRef: BsModalRef;

    dtOptions: DataTables.Settings = {};
    postList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    constructor(
        public pageTitle: Title,
        private modalService: BsModalService,
        private toastr: ToastrService,
        private momentFactory: MomentsService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud -  Moments Post");
        this.getAllPosts();
    }

    getAllPosts() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.momentFactory
                    .getAllPosts(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.postList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "createdAt", searchable: false },
                { data: "text" },
                { data: "", name: "userDetails.firstName" },
                { data: "reports", searchable: false },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

    detailsModal(id) {
        const initialState = { postId: id, type: "Post" };
        this.modalRef = this.modalService.show(ViewPostDetailsComponent, {
            class: 'modal-dialog-centered modal-lg',
            initialState
        });
    }

    changePostStatus(postId, type) {
        let text = "You want to activate this post?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Post has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this post?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Post has been deactivated.";
        }
        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.momentFactory.activeInActivePost({ "postId": postId, "status": type }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

}
