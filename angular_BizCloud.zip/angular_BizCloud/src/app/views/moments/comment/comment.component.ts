import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import Swal from 'sweetalert2';
import { MomentsService } from '../moments.services';
import { ViewPostDetailsComponent } from '../view-post-details/view-post-details.component';

@Component({
    selector: 'app-comment',
    templateUrl: './comment.component.html'
})
export class CommentComponent implements OnInit {

    postList: Array<any>;

    @ViewChild(DataTableDirective)
    dtElement: DataTableDirective;

    dtTrigger: Subject<any> = new Subject();

    dtOptions: DataTables.Settings = {
        "lengthChange": false
    };

    modalRef: BsModalRef;

    constructor(
        public pageTitle: Title,
        private modalService: BsModalService,
        private momentFactory: MomentsService,
        private toastr: ToastrService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud -  Moments Comment");
        this.getAllReportedComments()
    }

    getAllReportedComments() {
        this.dtOptions = {
            pagingType: "full_numbers",
            pageLength: 10,
            serverSide: true,
            processing: true,
            stateSave: true,
            ajax: (dataTablesParameters: any, callback) => {
                this.momentFactory
                    .getAllReportCommentListing(dataTablesParameters)
                    .subscribe(
                        respones => {
                            let resData = JSON.parse(JSON.stringify(respones));
                            this.postList = resData.data;
                            callback({
                                recordsTotal: resData.recordsTotal,
                                recordsFiltered: resData.recordsFiltered,
                                data: []
                            });
                        },
                        error => {
                            this.toastr.error(
                                "Oops! something went wrong !.",
                                "Error"
                            );
                        }
                    );
            },
            scrollCollapse: true,
            columns: [
                { data: "createdAt", searchable: false },
                { data: "issue" },
                { data: "", name: "userDetails.firstName" },
                { data: "", searchable: false, orderable: false }
            ]
        };
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

    changeCommentStatus(commentId, type) {
        let text = "You want to activate this comment?";
        let confirmButtonText = "Yes, Active it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Activated";
        let succMsg = "Comment has been activated.";
        if (type === 'inactive') {
            text = "You want to deactivate this comment?";
            confirmButtonText = "Yes, Deactive it!";
            confirmButtonColor = "#E0A801";
            succTitle = "Deactivated";
            succMsg = "Comment has been deactivated.";
        }
        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.momentFactory.activeInActiveReportedComment({ "commentId": commentId, "status": type }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

    detailsModal(id) {
        const initialState = { postId: id, type: "Post" };
        this.modalRef = this.modalService.show(ViewPostDetailsComponent, {
            class: 'modal-dialog-centered modal-lg',
            initialState
        });
    }

    resolveReportedComment(id) {
        let text = "You want to resolve this comment?";
        let confirmButtonText = "Yes, Resolve it!";
        let confirmButtonColor = "#008000";
        let succTitle = "Resolved";
        let succMsg = "Comment has been resolved.";
        
        Swal.fire({
            title: 'Are you sure?',
            text: text,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: '#d33',
            confirmButtonText: confirmButtonText
        }).then((result) => {
            if (result.isConfirmed) {
                this.momentFactory.resolveReportedComment({ "commentId": id }).subscribe(
                    response => {
                        Swal.fire(succMsg, '', 'success')
                        this.rerender();
                    },
                    error => {
                        this.toastr.error("Oops! something went wrong!.", "Error");
                    }
                );
            }
        })
    }

}
