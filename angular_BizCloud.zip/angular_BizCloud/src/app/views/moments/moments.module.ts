import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MomentsRoutingModule } from './moments-routing.module';
import { MomentsComponent } from './moments/moments.component';
import { PostComponent } from './post/post.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';
import { CommentComponent } from './comment/comment.component';
import { DataTablesModule } from 'angular-datatables';
import { ModalModule } from 'ngx-bootstrap/modal';
import { MomentsService } from './moments.services';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { ViewPostDetailsComponent } from './view-post-details/view-post-details.component';
// import { DateAgoPipe } from '../../pipes/date-ago.pipe';
import { ArticleComponent } from './article/article.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    declarations: [MomentsComponent, PostComponent, AdvertisementComponent, CommentComponent, ViewPostDetailsComponent, ArticleComponent],
    imports: [
        CommonModule,
        MomentsRoutingModule,
        DataTablesModule,
        ModalModule.forRoot(),
        SlickCarouselModule,
        SharedModule
    ],
    providers: [MomentsService],
    entryComponents: [
        ViewPostDetailsComponent
    ]
})
export class MomentsModule { }
