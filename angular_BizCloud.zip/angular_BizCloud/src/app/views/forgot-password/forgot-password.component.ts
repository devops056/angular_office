import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-forgot-password',
    templateUrl: 'forgot-password.component.html'
})
export class ForgotPasswordComponent {
    constructor(
        public pageTitle: Title
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Forgot Password");
    }
}
