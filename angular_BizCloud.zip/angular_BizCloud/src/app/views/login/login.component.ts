import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { CustomValidators } from 'ng2-validation';
import { CusAuthService } from '../../helpers/customauth.services';
import { LoginService } from './login.services';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-login',
    templateUrl: 'login.component.html'
})
export class LoginComponent {

    loginForm: FormGroup;
    submitted: boolean = false;

    constructor(
        public pageTitle: Title,
        public loginFactory: LoginService,
        public router: Router,
        public authFactory: CusAuthService,
        private toastr: ToastrService,
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Login");
        this.createForm()
    }

    createForm() {
        this.loginForm = new FormGroup({
            email: new FormControl('', [
                Validators.required,
                CustomValidators.email
            ]),
            password: new FormControl("", [
                Validators.required
            ])
        })
    }

    loginFormSubmit() {
        this.submitted = true;
        if (this.loginForm.valid) {
            this.loginFactory.adminLogin(this.loginForm.value).subscribe(
                response => {
                    let adminDetails = JSON.parse(JSON.stringify(response));
                    if (adminDetails.status == 200) {
                        this.authFactory.setAuthData(adminDetails.data);
                        this.router.navigate(["/dashboard"]);
                    } else {
                        this.toastr.error(adminDetails.message, 'Error');
                    }
                },
                error => {
                    this.toastr.error(
                        "Oops! Something went wrong",
                        "Error",
                    );
                }
            );
        }
    }
}
