import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ChangepasswordService } from './change-password.services';

@Component({
    selector: 'app-change-password',
    templateUrl: './change-password.component.html'
})
export class ChangePasswordComponent implements OnInit {

    password1: any = "password";
    password2: any = "password";
    password3: any = "password";
    show1: boolean = false;
    show2: boolean = false;
    show3: boolean = false;

    changePasswordForm: FormGroup;
    submitted: boolean = false;

    constructor(
        public pageTitle: Title,
        private router: Router,
        private toastr: ToastrService,
        private changePasswordFactory: ChangepasswordService
    ) { }

    ngOnInit(): void {
        this.pageTitle.setTitle("BizCloud - Change Password");
        this.createForm();
    }

    createForm() {
        this.changePasswordForm = new FormGroup({
            'currPassword': new FormControl('', [Validators.required]),
            'newPassword': new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]),
            'confPassword': new FormControl('', [Validators.required])
        });
    }

    changePasswordFormSubmit() {
        this.submitted = true;
        if (this.changePasswordForm.valid) {
            let sendDataToApi = {
                "oldPassword": this.changePasswordForm.value.currPassword,
                "newPassword": this.changePasswordForm.value.newPassword
            };
            this.changePasswordFactory.changePassword(sendDataToApi).subscribe(
                response => {
                    let resData = JSON.parse(JSON.stringify(response));
                    if (resData.status == 200) {
                        this.toastr.success(resData.message, 'Success');
                        this.router.navigate(["/dashboard"]);
                    } else {
                        this.toastr.error(resData.message, 'Error');
                    }
                },
                error => {
                    this.toastr.error('Oops! something went wrong', 'Error');
                }
            );
        }
    }

    changeType(id) {
        if (id == 1) {
            if (this.password1 === 'password') {
                this.password1 = 'text';
                this.password1 = (this.password1 !== 'text');
                this.show1 = true;
            } else {
                this.password1 = 'password';
                this.show1 = false;
            }
        } else if (id == 2) {
            if (this.password2 === 'password') {
                this.password2 = 'text';
                this.password2 = (this.password2 !== 'text');
                this.show2 = true;
            } else {
                this.password2 = 'password';
                this.show2 = false;
            }
        } else if (id == 3) {
            if (this.password3 === 'password') {
                this.password3 = 'text';
                this.password3 = (this.password3 !== 'text');
                this.show3 = true;
            } else {
                this.password3 = 'password';
                this.show3 = false;
            }
        }
    }

}
