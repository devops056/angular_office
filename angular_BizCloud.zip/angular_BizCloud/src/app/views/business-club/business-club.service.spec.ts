import { TestBed } from '@angular/core/testing';

import { BusinessClubService } from './business-club.service';

describe('BusinessClubService', () => {
  let service: BusinessClubService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusinessClubService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
