import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../../environments/environment';
import { BusinessClubService } from '../business-club.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-club-view',
  templateUrl: './club-view.component.html',
  styleUrls: ['./club-view.component.scss']
})
export class ClubViewComponent implements OnInit {

  id: string = "";
  groupDetails: any = {};
  baseURLPath = environment.GETIMGFOLDER + "groups/"

  constructor(
    public pageTitle: Title,
    public route: ActivatedRoute,
    public businessClubFactory: BusinessClubService,
    public toasterService: ToastrService,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.pageTitle.setTitle("BizCloud - Manage Business Club");
    this.route.params.subscribe(params => {
      this.id = params.id;
    });

    this.getViewDetails();
  }

  userImgErr(event) {
    event.target.src = environment.PLACEHOLDERIMG
  }

  getViewDetails() {
    this.businessClubFactory.fetchDetailsOfBusinessClub({ "groupId": this.id }).subscribe(
      response => {
        let getGroupDetails = JSON.parse(JSON.stringify(response));
        if (getGroupDetails.status == 200) {
          this.groupDetails = getGroupDetails.data;
        } else {
          this.groupDetails = {};
        }
      },
      error => {
        this.toasterService.error("Oops! Something went wrong!", "Error")
      }
    );
  }

  goBack() {
    this.location.back();
  }

}
