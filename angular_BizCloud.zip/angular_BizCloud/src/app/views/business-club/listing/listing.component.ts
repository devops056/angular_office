import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { BusinessClubService } from '../business-club.service';

@Component({
	selector: 'app-listing',
	templateUrl: './listing.component.html',
	styleUrls: ['./listing.component.scss']
})
export class ListingComponent implements OnInit {

	dtOptions: DataTables.Settings = {};
	users: Array<any>;

	@ViewChild(DataTableDirective)
	dtElement: DataTableDirective;

	dtTrigger: Subject<any> = new Subject();

	baseURLPath = environment.GETIMGFOLDER + "groups/"

	constructor(
		public pageTitle: Title,
		private toasterService: ToastrService,
		private businessClubFactory: BusinessClubService
	) { }

	ngOnInit(): void {
		this.pageTitle.setTitle("BizCloud - Manage Business Club");
		this.getAllBusinessClub();
	}

	getAllBusinessClub() {
		this.dtOptions = {
			pagingType: "full_numbers",
			pageLength: 10,
			serverSide: true,
			processing: true,
			// stateSave: true,
			// 'columnDefs': [ {
			//     'targets': [0], // column index (start from 0)
			//     'orderable': false, // set orderable false for selected columns
			//  }],
			"order": [1, "asc"],
			ajax: (dataTablesParameters: any, callback) => {

				this.businessClubFactory
					.fetchListOfBusinessClub(dataTablesParameters)
					.subscribe(
						respones => {
							let resData = JSON.parse(JSON.stringify(respones));
							this.users = resData.data;

							callback({
								recordsTotal: resData.recordsTotal,
								recordsFiltered: resData.recordsFiltered,
								data: []
							});
						},
						error => {
							this.toasterService.error(
								"Oops! something went wrong !.",
								"Error"
							);
						}
					);
			},
			scrollCollapse: true,
			columns: [
				{ data: "groupIcon", searchable: false, orderable: false },
				{ data: "groupName" },
				{ data: "groupType" },
				{ data: "totalMembers", searchable: false },
				{ data: "createdAt", searchable: false },
				{ data: "", searchable: false, orderable: false }
			]
		};
	}

	userImgErr(event) {
        event.target.src = environment.PLACEHOLDERIMG
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        this.dtTrigger.unsubscribe();
	}
	
	rerender(): void {
        this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next();
        });
    }

}
