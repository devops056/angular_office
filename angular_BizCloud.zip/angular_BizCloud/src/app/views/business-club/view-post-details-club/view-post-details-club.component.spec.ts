import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPostDetailsClubComponent } from './view-post-details-club.component';

describe('ViewPostDetailsClubComponent', () => {
  let component: ViewPostDetailsClubComponent;
  let fixture: ComponentFixture<ViewPostDetailsClubComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPostDetailsClubComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPostDetailsClubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
