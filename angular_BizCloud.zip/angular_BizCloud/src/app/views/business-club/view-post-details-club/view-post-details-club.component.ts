import { Component, Input, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { environment } from '../../../../environments/environment';
import { BusinessClubService } from '../business-club.service';

@Component({
  selector: 'app-view-post-details-club',
  templateUrl: './view-post-details-club.component.html',
  styleUrls: ['./view-post-details-club.component.scss']
})
export class ViewPostDetailsClubComponent implements OnInit {

  @Input() postId;
  @Input() groupId;

  baseURLPathProfile = environment.GETIMGFOLDER + "profile/"
  baseURLPathImg = environment.GETIMGFOLDER + "post/image/"
  baseURLPathVideo = environment.GETIMGFOLDER + "post/video/"

  postDetails;

  slides = [];

  type;

  slideConfig = { "slidesToShow": 1, "slidesToScroll": 1 };

  constructor(
    private modalService: BsModalService,
    public modalRef: BsModalRef,
    private businessClubFactory: BusinessClubService
  ) { }

  ngOnInit(): void {
    this.businessClubFactory.getPostDetailsOfBusinessClub({ "postId": this.postId, "groupId": this.groupId }).subscribe(res => {
      let getPostDetails = JSON.parse(JSON.stringify(res))

      if (getPostDetails.status == 200) {
        this.postDetails = getPostDetails.data;

        if (this.postDetails.PostMedias.length > 0) {
          if (this.postDetails.PostMedias[0].mediaType == 'image') {
            for (let postImg of this.postDetails.PostMedias) {
              this.slides.push({ "img": this.baseURLPathImg + postImg.mediaFile })
            }
          } else {

          }
        }

      } else {
        this.postDetails = [];
      }

    })
  }

  onClose() {
    this.modalRef.hide()
  }

  userImgErr(event) {
    event.target.src = environment.PLACEHOLDERIMG
  }

}
