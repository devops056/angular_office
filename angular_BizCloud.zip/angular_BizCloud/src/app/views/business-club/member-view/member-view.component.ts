import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Title } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { BusinessClubService } from '../business-club.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-member-view',
  templateUrl: './member-view.component.html',
  styleUrls: ['./member-view.component.scss']
})
export class MemberViewComponent implements OnInit {

  id: string = "";
  dtOptions: DataTables.Settings = {};
  users: Array<any>;

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;

  dtTrigger: Subject<any> = new Subject();

  baseURLPath = environment.GETIMGFOLDER + "profile/"

  constructor(
    public location: Location,
    public pageTitle: Title,
    private toasterService: ToastrService,
    private businessClubFactory: BusinessClubService,
    public route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.pageTitle.setTitle("BizCloud - Manage Business Club");
    this.route.params.subscribe(params => {
      this.id = params.id;
    });
    this.getAllMember();
  }

  goBack() {
    this.location.back();
  }

  getAllMember() {
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      serverSide: true,
      processing: true,
      // stateSave: true,
      // 'columnDefs': [ {
      //     'targets': [0], // column index (start from 0)
      //     'orderable': false, // set orderable false for selected columns
      //  }],
      "order": [6, "desc"],
      ajax: (dataTablesParameters: any, callback) => {
        dataTablesParameters.groupId = this.id

        this.businessClubFactory
          .getAllGroupMemberListing(dataTablesParameters)
          .subscribe(
            respones => {
              let resData = JSON.parse(JSON.stringify(respones));
              this.users = resData.data;

              callback({
                recordsTotal: resData.recordsTotal,
                recordsFiltered: resData.recordsFiltered,
                data: []
              });
            },
            error => {
              this.toasterService.error(
                "Oops! something went wrong !.",
                "Error"
              );
            }
          );
      },
      scrollCollapse: true,
      columns: [
        { data: "", searchable: false, orderable: false },
        { data: "", name: "UserDetails.email" },
        { data: "", name: "UserDetails.firstName" },
        { data: "", name: "UserDetails.lastName" },
        { data: "", name: "UserDetails.phoneNumber" },
        { data: "memberType", searchable: false },
        { data: "createdAt", searchable: false }
      ]

    };
  }

  userImgErr(event) {
    event.target.src = environment.PLACEHOLDERIMG
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

}
