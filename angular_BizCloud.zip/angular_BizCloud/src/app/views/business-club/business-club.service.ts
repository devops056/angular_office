import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
	providedIn: 'root'
})
export class BusinessClubService {

	constructor(private http: HttpClient) { }

	fetchListOfBusinessClub(data) {
		return this.http.post(environment.APIURL + 'api/fetchListOfBusinessClub', data);
	}

	fetchDetailsOfBusinessClub(data) {
		return this.http.post(environment.APIURL + 'api/fetchDetailsOfBusinessClub', data);
	}

	getAllGroupTopicListing(data) {
		return this.http.post(environment.APIURL + 'api/getAllGroupTopicListing', data);
	}

	fetchPostListsOfBusinessClub(data) {
		return this.http.post(environment.APIURL + 'api/fetchPostListsOfBusinessClub', data);
	}

	getAllGroupMemberListing(data) {
		return this.http.post(environment.APIURL + 'api/getAllGroupMemberListing', data);
	}

	activeInActiveBusinessClubPost(data) {
		return this.http.post(environment.APIURL + 'api/activeInActiveBusinessClubPost', data);
	}

	getPostDetailsOfBusinessClub(data) {
		return this.http.post(environment.APIURL + 'api/getPostDetailsOfBusinessClub', data);
	}
	
}
