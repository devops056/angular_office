import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataTableDirective } from 'angular-datatables';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { BusinessClubService } from '../business-club.service';
import { ViewPostDetailsClubComponent } from '../view-post-details-club/view-post-details-club.component';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-post-view',
  templateUrl: './post-view.component.html',
  styleUrls: ['./post-view.component.scss']
})
export class PostViewComponent implements OnInit {

  id: string = "";
  modalRef: BsModalRef;

  dtOptions: DataTables.Settings = {};
  postList: Array<any>;

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;

  dtTrigger: Subject<any> = new Subject();

  constructor(
    public pageTitle: Title,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private businessClubFactory: BusinessClubService,
    public location: Location,
    public route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.pageTitle.setTitle("BizCloud - Manage Business Club");
    this.route.params.subscribe(params => {
      this.id = params.id;
    });
    this.getAllPosts();
  }

  getAllPosts() {
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      serverSide: true,
      processing: true,
      stateSave: true,
      "order": [0, "asc"],
      ajax: (dataTablesParameters: any, callback) => {
        dataTablesParameters.groupId = this.id

        this.businessClubFactory
          .fetchPostListsOfBusinessClub(dataTablesParameters)
          .subscribe(
            respones => {
              let resData = JSON.parse(JSON.stringify(respones));
              this.postList = resData.data;
              
              callback({
                recordsTotal: resData.recordsTotal,
                recordsFiltered: resData.recordsFiltered,
                data: []
              });
            },
            error => {
              this.toastr.error(
                "Oops! something went wrong !.",
                "Error"
              );
            }
          );
      },
      scrollCollapse: true,
      columns: [
        { data: "createdAt", searchable: false },
        { data: "text" },
        { data: "", name: "userDetails.firstName" },
        { data: "reports", searchable: false },
        { data: "", searchable: false, orderable: false }
      ]
    };
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

  detailsModal(id) {
    const initialState = { postId: id, groupId: this.id, type: "Post" };
    this.modalRef = this.modalService.show(ViewPostDetailsClubComponent, {
      class: 'modal-dialog-centered modal-lg',
      initialState
    });
  }

  changePostStatus(postId, type) {
    let text = "You want to activate this post?";
    let confirmButtonText = "Yes, Active it!";
    let confirmButtonColor = "#008000";
    let succTitle = "Activated";
    let succMsg = "Post has been activated.";
    if (type === 'inactive') {
      text = "You want to deactivate this post?";
      confirmButtonText = "Yes, Deactive it!";
      confirmButtonColor = "#E0A801";
      succTitle = "Deactivated";
      succMsg = "Post has been deactivated.";
    }
    Swal.fire({
      title: 'Are you sure?',
      text: text,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: confirmButtonColor,
      cancelButtonColor: '#d33',
      confirmButtonText: confirmButtonText
    }).then((result) => {
      if (result.isConfirmed) {
        this.businessClubFactory.activeInActiveBusinessClubPost({ "postId": postId, "status": type }).subscribe(
          response => {
            Swal.fire(succMsg, '', 'success')
            this.rerender();
          },
          error => {
            this.toastr.error("Oops! something went wrong!.", "Error");
          }
        );
      }
    })
  }

  goBack() {
    this.location.back();
  }

}
