import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListingComponent } from './listing/listing.component';
import { BusinessClubRoutingModule } from './business-club-routing.module';
import { DataTablesModule } from 'angular-datatables';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { FormsModule } from '@angular/forms';
import { BusinessClubService } from './business-club.service';
import { ClubViewComponent } from './club-view/club-view.component';
import { PostViewComponent } from './post-view/post-view.component';
import { TopicViewComponent } from './topic-view/topic-view.component';
import { MemberViewComponent } from './member-view/member-view.component';
import { BsModalService, ModalModule } from 'ngx-bootstrap/modal';
import { ViewPostDetailsClubComponent } from './view-post-details-club/view-post-details-club.component';
import { SharedModule } from '../shared/shared.module';
import { SlickCarouselModule } from 'ngx-slick-carousel';


@NgModule({
  declarations: [ListingComponent, ClubViewComponent, PostViewComponent, TopicViewComponent, MemberViewComponent, ViewPostDetailsClubComponent],
  imports: [
    CommonModule,
    BusinessClubRoutingModule,
    DataTablesModule,
    CKEditorModule,
    FormsModule,
    SharedModule,
    ModalModule.forRoot(),
    SlickCarouselModule
  ],
  providers: [BusinessClubService],
  entryComponents: [
    ViewPostDetailsClubComponent
  ]
})
export class BusinessClubModule { }
