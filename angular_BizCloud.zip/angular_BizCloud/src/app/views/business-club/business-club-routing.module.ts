import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminAuth } from '../../helpers/adminAuth';
import { ClubViewComponent } from './club-view/club-view.component';
import { ListingComponent } from './listing/listing.component'
import { MemberViewComponent } from './member-view/member-view.component';
import { PostViewComponent } from './post-view/post-view.component';
import { TopicViewComponent } from './topic-view/topic-view.component';

const routes: Routes = [
    {
        path: '',
        data: {
            title: 'Business Club'
        },
        children: [
            {
                path: '',
                component: ListingComponent,
                data: {
                    title: 'Listing'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'view/:id',
                component: ClubViewComponent,
                data: {
                    title: 'View'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'view/:id/post/:pid',
                component: PostViewComponent,
                data: {
                    title: 'Post'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'view/:id/topic/:tid',
                component: TopicViewComponent,
                data: {
                    title: 'Topic'
                },
                canActivate: [AdminAuth]
            },
            {
                path: 'view/:id/member/:mid',
                component: MemberViewComponent,
                data: {
                    title: 'Member'
                },
                canActivate: [AdminAuth]
            },
        ]
    }
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class BusinessClubRoutingModule { }
