import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
    {
        name: 'Dashboard',
        url: '/dashboard',
        icon: 'fas fa-tachometer-alt-fast',
    },
    {
        name: 'Manage Users',
        url: '/manage-users',
        icon: 'fas fa-users',
    },
    {
        name: 'Moments',
        url: '/moments',
        icon: 'fas fa-comment-alt-plus',
        children: [
            {
                name: 'Moments',
                url: '/moments/moments',
                icon: 'fas fa-comment-alt'
            },
            {
                name: 'Post',
                url: '/moments/post',
                icon: 'fas fa-mailbox'
            },
            {
                name: 'Advertisement',
                url: '/moments/advertisement',
                icon: 'fas fa-ad'
            },
            {
                name: 'Comment',
                url: '/moments/comment',
                icon: 'fas fa-comment-alt-smile'
            }
        ]
    },
    {
        name: 'Evaluation',
        url: '/evaluation',
        icon: 'fas fa-atom',
    },
    {
        name: 'Labels',
        url: '/labels',
        icon: 'fas fa-tags',
        children: [
            {
                name: 'Business Goals',
                url: '/labels/matched',
                icon: 'fas fa-business-time'
            },
            {
                name: 'Preference',
                url: '/labels/preference',
                icon: 'fas fa-vote-yea'
            },
            {
                name: 'Industry',
                url: '/labels/industry',
                icon: 'fas fa-industry'
            },
            {
                name: 'Expertise',
                url: '/labels/expertise',
                icon: 'fas fa-chart-network'
            },
            {
                name: 'User Group',
                url: '/labels/user-group',
                icon: 'fas fa-users',
            },
        ]
    },
    {
        name: 'Subscription',
        url: '/subscription',
        icon: 'fas fa-wallet',
    },
    // {
    //     name: 'Generate Code',
    //     url: '/generate-code',
    //     icon: 'fas fa-shield-alt',
    // },
    {
        name: 'Content',
        url: '/content',
        icon: 'fas fa-ballot',
    },
    {
        name: 'Manage Admin',
        url: '/user-role',
        icon: 'fas fa-user-cog',
    }
];
