import { Injectable, OnInit } from "@angular/core";
import { BehaviorSubject } from 'rxjs';

@Injectable()
export class CusAuthService implements OnInit {
    cache: Object = null;
    token: String = "";

    private navItemsSource = new BehaviorSubject([]);
    navItemsObservable = this.navItemsSource.asObservable();

    constructor() {
        let adminDetails = JSON.parse(localStorage.getItem("adminDetails"));
        // console.log("custom auth")
        this.processNavItems()
    }

    ngOnInit() { }

    setAuthData(data) {
        if (data) {
            this.cache = data;
            localStorage.setItem("adminDetails", JSON.stringify(data));

            this.processNavItems()
        }
    }

    getAuthData() {
        return JSON.parse(localStorage.getItem("adminDetails"));
    }

    getNavItems() {
        return this.navItemsSource.value;
    }
    
    updateNavItems(data){
        this.navItemsSource.next(data);
    }

    processNavItems() {
        let storedPerms = this.getAuthData();
        if (storedPerms) {
            this.updateNavItems(storedPerms.permission);
        }
    }

    clearAuthData() {
        this.cache = null;
        localStorage.clear();
    }
}
