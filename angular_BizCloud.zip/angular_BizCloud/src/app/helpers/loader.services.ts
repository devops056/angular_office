import { Injectable } from '@angular/core';
import { Subject,Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  private subject1 = new Subject();

  constructor() {
    // this.subject1.next(false);
   }

  setLoading(status){
    this.subject1.next(status);
  }
  
  getLoading(): Observable<any>{
      // asObservable helps us to prevent the 
      // leaks of Observable from outside of the subject 
      return this.subject1.asObservable();
  }

}
