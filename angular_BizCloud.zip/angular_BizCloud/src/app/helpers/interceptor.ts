import { Injectable } from "@angular/core";
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse,
    HttpHeaders
} from "@angular/common/http";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";
import { CusAuthService } from './customauth.services';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../environments/environment';
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
    constructor(
        private authService: CusAuthService,
        private router: Router,
        public toasterService: ToastrService,
        private spinner: NgxSpinnerService
    ) { }

    intercept(
        request: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        this.spinner.show();

        const adminDetails = this.authService.getAuthData();

        if (
            adminDetails &&
            adminDetails.accessToken &&
            adminDetails.accessToken != ""
        ) {
            request = request.clone({
                setHeaders: {
                    Authorization: adminDetails.accessToken,
                    language: environment.DEFAULTLANG
                }
            });
        } else {
            request = request.clone({
                setHeaders: {
                    language: environment.DEFAULTLANG
                }
            })
        }

        return next.handle(request).pipe(tap(
            (event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {
                    this.spinner.hide();
                }
            },
            (err: any) => {
                if (err instanceof HttpErrorResponse) {
                    this.spinner.hide();
                    if (err.status == 401) {
                        this.toasterService.error(
                            "Your Session Has Expired. Please Login Again.",
                            "Error"
                        );
                        this.authService.clearAuthData();
                        setTimeout(() => {
                            this.router.navigate(["/login"]);
                        }, 1000);
                    }
                }
            }
        ));
    }
}
