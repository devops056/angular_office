import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CusAuthService } from './customauth.services';

@Injectable()
export class AdminAuth implements CanActivate {

    constructor(
        private router: Router, 
        private authFactory: CusAuthService,
        private toastr: ToastrService
    ) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        
        if (localStorage.getItem('adminDetails')) {

            let parsedJSON = JSON.parse(localStorage.getItem('adminDetails'))

            for (let urlData of parsedJSON.permission) {

                // console.log("state.url", state.url)
                // console.log("state.url", state.url.split('/')[1] == 'evaluation')
                // console.log(state.url.includes(urlData.url))
                // console.log(state.url.split('/')[1])
                // console.log(state.url.split('/')[1].includes(urlData.url))

                if (state.url.includes(urlData.url)) {
                    return true;
                }

                if (state.url.split('/')[1] == 'evaluation') {
                    if (urlData.url.includes(state.url.split('/')[1])) {
                        return true;
                    }
                }

                if (state.url.split('/')[1] == 'change-password') {
                    return true;
                }
            }

            // let obj = parsedJSON.permission.find(o => o.url === state.url);
            // console.log(obj)

            // return true;
        }

        // this.toastr.error("Not Authorized", "Error");
        this.router.navigate(['/login']);
        this.authFactory.clearAuthData()
        return false;
    }
}
