import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CusAuthService } from '../../helpers/customauth.services';
import { navItems } from '../../_nav';

@Component({
    selector: 'app-dashboard',
    templateUrl: './default-layout.component.html'
})
export class DefaultLayoutComponent implements OnInit {
    public sidebarMinimized = false;
    public navItems = [];

    constructor(private authFactory: CusAuthService, private router: Router) {
        // console.log('cons ccalled')
        this.dynamicNavigation()
    }

    ngOnInit(): void {

    }

    year = new Date();

    toggleMinimize(e) {
        this.sidebarMinimized = e;
    }

    logoutBtn() {
        this.authFactory.clearAuthData();
        this.router.navigate(['/login']);
    }


    dynamicNavigation() {
        let thirdLength = null;
        let ninethLength = null;
        let fifteenth = null;

        this.authFactory.navItemsObservable.subscribe(response => {
            let navData = [];

            let navigationsLength = response.length;

            // console.log(response)

            response.forEach((menuItem, index) => {
                // console.log(menuItem)
                if (menuItem.module_id == 3) {
                    if (!navData.hasOwnProperty(thirdLength)) {
                        thirdLength = navData.length
                        navData.push({ name: 'Moments', url: '/moments', icon: 'fas fa-comment-alt-plus', children: [] })
                    }
                    navData[thirdLength].children.push(menuItem)

                } else if (menuItem.module_id == 9) {
                    if (!navData.hasOwnProperty(ninethLength)) {
                        ninethLength = navData.length
                        navData.push({ name: 'Labels', url: '/labels', icon: 'fas fa-tags', children: [] })
                    }
                    navData[ninethLength].children.push(menuItem)

                } else if (menuItem.module_id == 15) {
                    if (!navData.hasOwnProperty(fifteenth)) {
                        fifteenth = navData.length
                        navData.push({ name: 'Generate Codes', url: '/generate-code', icon: 'fas fa-shield-alt', children: [] })
                    } else {
                        navData[fifteenth].children.push(menuItem)

                    }
                } else {
                    navData.push(menuItem);
                }

                if (navigationsLength - 1 == index) {
                    // console.log(navData)

                    this.navItems = navData;
                }

            })

        });
    }

}
