import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Import Containers
import { DefaultLayoutComponent } from './containers';
import { AdminAuth } from './helpers/adminAuth';

import { P404Component } from './views/error/404.component';
import { P500Component } from './views/error/500.component';
import { ResetPasswordComponent } from './views/reset-password/reset-password.component';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'dashboard', // login
        pathMatch: 'full',
    },
    {
        path: '404',
        component: P404Component,
        data: {
            title: 'Page 404'
        }
    },
    {
        path: '500',
        component: P500Component,
        data: {
            title: 'Page 500'
        }
    },
    {
        path: 'reset-password/:resetToken',
        loadChildren: () => import('./views/reset-password/reset-password.module').then(m => m.ResetPasswordModule)
    },
    {
        path: 'login',
        loadChildren: () => import('./views/login/login.module').then(m => m.LoginModule)
    },
    {
        path: '',
        component: DefaultLayoutComponent,
        // canActivate: [AdminAuth],
        data: {
            title: 'Home'
        },
        children: [
            {
                path: 'dashboard',
                loadChildren: () => import('./views/dashboard/dashboard.module').then(m => m.DashboardModule)
            },
            {
                path: 'change-password',
                loadChildren: () => import('./views/change-password/change-password.module').then(m => m.ChangePasswordModule)
            },
            {
                path: 'labels',
                loadChildren: () => import('./views/labels/labels.module').then(m => m.LabelsModule)
            },

            {
                path: 'base',
                loadChildren: () => import('./views/base/base.module').then(m => m.BaseModule)
            },
            {
                path: 'manage-users',
                loadChildren: () => import('./views/manage-users/manage-users.module').then(m => m.ManageUsersModule)
            },
            {
                path: 'subscription',
                loadChildren: () => import('./views/subscription/subscription.module').then(m => m.SubscriptionModule)
            },
            {
                path: 'moments',
                loadChildren: () => import('./views/moments/moments.module').then(m => m.MomentsModule)
            },
            {
                path: 'evaluation/:type/:id',
                loadChildren: () => import('./views/evaluation/evaluation.module').then(m => m.EvaluationModule)
            },
            {
                path: 'generate-code',
                loadChildren: () => import('./views/generate-code/generate-code.module').then(m => m.GenerateCodeModule)
            },
            {
                path: 'content',
                loadChildren: () => import('./views/content/content.module').then(m => m.ContentModule)
            },
            {
                path: 'user-role',
                loadChildren: () => import('./views/user-role/user-role.module').then(m => m.UserRoleModule)
            },
            {
                path: 'business-club',
                loadChildren: () => import('./views/business-club/business-club.module').then(m => m.BusinessClubModule)
            },
        ]
    },
    { path: '**', component: P404Component }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
