const BASEURL = "http://202.131.117.92:7075";
export const environment = {
  production: true,
  APIURL: BASEURL + "/admin_v1/",
  PLACEHOLDERIMG: BASEURL + "/assets/img/avatars/placeholder.png",
  GETIMGFOLDER: BASEURL + "/uploads/",
  BASEURLV1: BASEURL + '/v1/',
  DEFAULTLANG: 'en'
};
